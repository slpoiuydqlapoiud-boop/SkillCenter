# 数通伙伴赋能作战看板 · 前台工程

包含当前站点的完整静态前台源代码及插图，无需构建、无需 npm install，无外部 CDN 依赖。

## Windows：直接打开（无需安装开发环境）
1. 将整个 ZIP 解压到任意目录，不能直接在压缩包内运行。
2. 双击 start.bat；也可以直接用 Chrome 或 Edge 打开 dist/index.html。
3. 可离线使用所有前台页面、筛选、图表、明细和 CSV 导出。

文件模式下浏览器本地存储的行为由浏览器决定。需要稳定保存本地任务时，建议使用下面的 HTTP 模式。

## Windows：本地 HTTP 服务（推荐开发和演示）
PC 已安装 Node.js 或 Python 3 时：
1. 双击 start-server.bat。
2. 浏览器访问 http://127.0.0.1:8080/ 。若启动时页面未加载，刷新一次。
3. 保持命令窗口打开；按 Ctrl+C 停止服务。

也可以在工程目录执行：
- Node.js：npm start，或 node server.cjs
- Python 3：py -3 -m http.server 8080 --bind 127.0.0.1 --directory dist

本工程不包含 Node.js/Python 运行时。两者都未安装时，仍可使用 start.bat 直接打开。
端口占用时可用命令：set PORT=8081 然后 node server.cjs；访问 http://127.0.0.1:8081/ 。
服务默认只监听本机，不需要网络或 ChatGPT 登录。

## macOS / Linux
安装 Node.js 或 Python 3 后，在工程目录执行 sh start.sh，然后访问 http://127.0.0.1:8080/ 。
也可以直接用浏览器打开 dist/index.html。

## 工程结构
- dist/index.html：页面入口、导航与通用交互组件
- dist/style.css：华为风格样式及响应式布局
- dist/app.js：作战总览、伙伴地图、场景作战、任务、项目明细、数据湖视图及演示数据
- dist/enablement.js：学、讲、测、看、营五环节指标看板
- dist/project-dashboards.js：项目漏斗、工具商机来源、订货与收入走势
- dist/assets/：本地插图资源
- server.cjs：不依赖第三方包的 Node.js 静态服务器
- start.bat / start-server.bat / start.sh：启动脚本

直接修改 HTML/CSS/JS，刷新浏览器即可生效。

## 数据及迁移说明
- 包含7个页面：作战总览、伙伴地图、场景作战、伙伴使能、项目运作、作战明细、作战数据湖。
- 伙伴使能保留用户提供的6项汇总指标和增长率；未提供的9项显示“待接入”。
- 伙伴、项目、来源归因、订货与收入等为演示数据，未接入华为内部系统。
- 本工程只有前台，没有后端、数据库、账号权限或真实业务接口。
- 新建任务和状态更新保存在当前浏览器 localStorage；不是共享数据库。
- 复制工程不会携带原 PC 或线上站点浏览器中的任务记录。更换浏览器、路径、端口或清理浏览器存储也可能导致原本地任务不可见。
- 图片已放在工程内，运行不依赖在线站点。

快照日期：2026-10-30。包含五环节使能看板及三个项目运作局部看板的最新版本。
