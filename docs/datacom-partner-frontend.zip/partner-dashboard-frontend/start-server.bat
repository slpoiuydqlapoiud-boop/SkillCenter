@echo off
cd /d "%~dp0"
where node >nul 2>nul
if not errorlevel 1 (
  start "" "http://127.0.0.1:8080/"
  node server.cjs
  pause
  exit /b
)
py -3 --version >nul 2>nul
if not errorlevel 1 (
  start "" "http://127.0.0.1:8080/"
  py -3 -m http.server 8080 --bind 127.0.0.1 --directory dist
  pause
  exit /b
)
python --version >nul 2>nul
if not errorlevel 1 (
  start "" "http://127.0.0.1:8080/"
  python -m http.server 8080 --bind 127.0.0.1 --directory dist
  pause
  exit /b
)
echo Node.js or Python 3 is required for HTTP server mode.
echo Alternatively, double-click start.bat for offline file mode.
pause
