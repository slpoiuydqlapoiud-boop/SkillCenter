#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
if command -v node >/dev/null 2>&1; then
  exec node server.cjs
elif command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server 8080 --bind 127.0.0.1 --directory dist
else
  echo 'Install Node.js or Python 3, or open dist/index.html directly.'
  exit 1
fi
