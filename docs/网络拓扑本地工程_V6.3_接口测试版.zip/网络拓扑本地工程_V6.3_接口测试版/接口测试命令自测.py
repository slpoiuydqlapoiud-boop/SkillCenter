#!/usr/bin/env python3
"""仅连接本机测试服务器；不会调用真实模型或传输 Excel。"""
import json,os,shutil,socket,subprocess,sys,tempfile,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SECRET='mock-credential-local-test'
class Mock(BaseHTTPRequestHandler):
    def do_POST(self):
        assert self.headers.get('Authorization')=='Bearer '+SECRET
        data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        assert data['model']=='mock' and data['max_tokens']==777 and 'connection' in data['messages'][1]['content']
        if self.path=='/400':
            raw=json.dumps({'error':{'message':'invalid model; received key '+SECRET}}).encode();self.send_response(400);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if self.path in ('/401','/404','/429'):
            self.send_error(int(self.path[1:]));return
        if self.path=='/malformed':raw=b'not-json'
        else:
            reason='length' if self.path=='/length' else 'stop'
            content='' if self.path=='/empty' else json.dumps({'ok':True})
            raw=json.dumps({'model':'mock','choices':[{'finish_reason':reason,'message':{'content':content}}]}).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def log_message(self,*args):pass
s=ThreadingHTTPServer(('127.0.0.1',0),Mock);threading.Thread(target=s.serve_forever,daemon=True).start()
try:
    with tempfile.TemporaryDirectory() as d:
        root=Path(d);(root/'src').mkdir()
        for name in ('model_api.py','model_profiles.py','api_probe.py'):shutil.copy2(ROOT/'src'/name,root/'src'/name)
        shutil.copy2(ROOT/'启动验证.py',root/'启动验证.py')
        cfg={'url':'http://127.0.0.1:'+str(s.server_port)+'/success','model':'mock','api_key_env':'TEST_KEY','max_tokens':777,'timeout_seconds':5}
        (root/'模型配置.json').write_text(json.dumps(cfg),encoding='utf-8')
        env=os.environ.copy();env['TEST_KEY']=SECRET
        def execute(path):
            cfg['url']='http://127.0.0.1:'+str(s.server_port)+'/'+path
            (root/'模型配置.json').write_text(json.dumps(cfg),encoding='utf-8')
            return subprocess.run([sys.executable,str(root/'启动验证.py'),'--test-api'],cwd=root,env=env,text=True,encoding='utf-8',capture_output=True,timeout=12)
        for path,expected,code in [('success','测试通过',0),('400','invalid model',1),('401','HTTP 401',1),('404','HTTP 404',1),('429','HTTP 429',1),('malformed','不是有效 JSON',1),('length','token 上限',1),('empty','message.content',1)]:
            result=execute(path);output=result.stdout+result.stderr
            assert result.returncode==code and expected in output,(path,result.returncode,output)
            assert SECRET not in output
        # Same production call accepts an arbitrary public HTTP host (mocked opener, no actual connection).
        sys.path.insert(0,str(root/'src'));import model_api
        class Response:
            status=200
            def __enter__(self):return self
            def __exit__(self,*a):pass
            def read(self,*a):return json.dumps({'choices':[{'finish_reason':'stop','message':{'content':'{"ok":true}'}}]}).encode()
        class Opener:
            def open(self,*a,**kw):return Response()
        old=model_api.urllib.request.build_opener;model_api.urllib.request.build_opener=lambda *_:Opener()
        try:
            with tempfile.TemporaryDirectory() as out:
                result,_=model_api.call({'url':'http://public.example/v1/chat/completions','model':'mock'},SECRET,{},Path(out))
                assert result=={'ok':True}
        finally:model_api.urllib.request.build_opener=old
        assert not (root/'input.xlsx').exists() and not (root/'output').exists()
    print('通过：HTTP 请求、无 Excel 测试、正常 JSON、401/404/429、无效 JSON、输出截断、空内容及密钥不回显。')
finally:s.shutdown();s.server_close()
