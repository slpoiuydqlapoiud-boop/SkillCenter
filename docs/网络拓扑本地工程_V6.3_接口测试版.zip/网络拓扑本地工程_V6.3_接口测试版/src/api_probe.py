"""Small, real request through the same production API function; no Excel sent."""
import json,tempfile,time
from pathlib import Path
from model_api import call

def test_api(cfg,token,timeout=None):
    run_cfg=dict(cfg);run_cfg['resume_model_calls']=False
    if timeout is None:timeout=min(float(cfg.get('timeout_seconds',600)),120.0)
    if timeout<=0:raise ValueError('测试超时必须大于 0 秒')
    run_cfg['timeout_seconds']=timeout
    print('正在发送一条简短的接口测试请求，不读取、不上传 Excel。',flush=True)
    print('测试使用当前模型配置中的 max_tokens；超时上限：'+str(timeout)+' 秒。',flush=True)
    start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='topology_api_probe_') as temp:
        out=Path(temp)
        try:
            result,diag=call(run_cfg,token,{'test':'connection'},out,prompt='连接与格式测试。请只返回 JSON 对象 {"ok":true}，不要包含其他内容。')
        except (ValueError,OSError,KeyError) as e:
            file=out/'模型调用诊断.json';diag={}
            if file.exists():
                try:diag=json.loads(file.read_text(encoding='utf-8'))
                except (ValueError,OSError):pass
            if diag.get('status')==200:
                print('测试未通过：接口返回 HTTP 200，但响应未满足本工程所需格式或未正常结束。',flush=True)
                print('原因：'+str(e),flush=True)
                if diag.get('finish_reason')=='length':
                    print('响应达到输出上限；检查所选配置的 max_tokens、服务限制及推理模型的思考 token。',flush=True)
                usage=diag.get('usage')
                if isinstance(usage,dict):
                    details=usage.get('completion_tokens_details')
                    details=details if isinstance(details,dict) else {}
                    for label,value in [('输入 token',usage.get('prompt_tokens')),('输出 token',usage.get('completion_tokens')),('其中思考 token',details.get('reasoning_tokens'))]:
                        if isinstance(value,(int,float)) and not isinstance(value,bool):print(label+'：'+str(value),flush=True)
                print('请核对服务是否支持 OpenAI Chat Completions、JSON 输出和当前模型参数。',flush=True)
            else:
                print('测试未通过：'+str(e),flush=True)
            print('耗时：'+str(round(time.monotonic()-start,2))+' 秒',flush=True)
            return 1
        print('测试通过：接口返回有效的 JSON 对象，本工程能解析该响应。',flush=True)
        print('HTTP 状态：'+str(diag.get('status'))+'；结束原因：'+str(diag.get('finish_reason'))+'；耗时：'+str(diag.get('duration_seconds'))+' 秒。',flush=True)
        print('该测试只验证小请求与本工程的基本格式兼容，不保证大规模拓扑推理、额度或输出长度。',flush=True)
        return 0
