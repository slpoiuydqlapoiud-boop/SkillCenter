// DOM 模拟验证，不等于实际浏览器端到端测试。
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const filename=process.argv[2];if(!filename)throw new Error('请传入生成的交互 HTML 文件路径');
const html=fs.readFileSync(filename,'utf8');const payload=html.match(/<script type="application\/json" id="payload">([\s\S]*?)<\/script>/)[1];const data=JSON.parse(payload);const code=html.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
class El{constructor(id){this.id=id;this.children=[];this.dataset={};this.style={};this.value='';this.events={};this._text='';this.view=''}get textContent(){return this._text+this.children.map(x=>x.textContent).join('')}set textContent(x){this._text=String(x);this.children=[]}appendChild(x){this.children.push(x);return x}replaceChildren(){this.children=[];this._text=''}addEventListener(k,v){this.events[k]=v}setAttribute(k,v){if(k==='viewBox')this.view=v}querySelector(q){return this.id==='stage'&&q==='svg'?svg:null}querySelectorAll(){return []}setPointerCapture(){}releasePointerCapture(){}getScreenCTM(){return {a:1,d:1}}}
const svg=new El('svg'),graphics=data.nodes.map(n=>{let x=new El('g');x.dataset.name=n.name;return x});svg.querySelectorAll=()=>graphics;const els=new Map(),document={getElementById(id){if(!els.has(id))els.set(id,new El(id));return els.get(id)},createElement:()=>new El('generated')};document.getElementById('payload').textContent=payload;
vm.runInNewContext(code,{document,console,Map,Set},{timeout:20000});assert.equal(svg.view,'0 0 3200 1800');
const member=data.clusters.find(x=>x.members.length>1).members[0];document.getElementById('query').value=member;document.getElementById('search').onclick();assert(document.getElementById('results').textContent.includes(member));
const selected=graphics.find(x=>x.dataset.name===member);svg.events.click({target:{closest:()=>selected}});assert(document.getElementById('details').textContent.includes(member));assert(document.getElementById('details').textContent.includes('同父单邻居组'));
document.getElementById('zoom-in').onclick();assert.notEqual(svg.view,'0 0 3200 1800');document.getElementById('reset').onclick();assert.equal(svg.view,'0 0 3200 1800');
console.log('通过：载入、名称搜索、节点详情、同父成员、缩放和复位（DOM 模拟，非真实浏览器）。');
