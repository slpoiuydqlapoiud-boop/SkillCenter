#!/usr/bin/env python3
"""Test-only mock HTTP model. It does not infer topology semantics."""
import json,sys,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
class Mock(BaseHTTPRequestHandler):
    maps=0;merges=0
    def do_POST(self):
        if self.headers.get('Authorization')!='Bearer mock-only':self.send_error(401);return
        req=json.loads(self.rfile.read(int(self.headers['Content-Length'])));e=json.loads(req['messages'][1]['content'])
        if 'page_id' in e:
            Mock.maps+=1;edges=e['edges'];gs=[]
            if edges and edges[0]['a']!=edges[0]['b']:
                z=edges[0];gs=[{'name':'模拟单链路组（非模型推理）','members':[z['a'],z['b']],'parents':[],'evidence_edge_ids':[z['id']],'reason':'仅验证程序接收模型返回的成员，不是业务分组'}]
            v={'reviewed_nodes':[n['name'] for n in e['nodes']],'reviewed_edges':[x['id'] for x in edges],'groups':gs,'node_assessments':[],'region_suggestions':[],'backbone_suggestions':[]}
        else:
            Mock.merges+=1;v={'reviewed_proposal_ids':[x['id'] for x in e['proposal_groups']],'operations':[],'region_names':[],'backbone_nodes':[],'analysis':'仅为本机模拟测试'}
        data=json.dumps({'model':'mock-only','choices':[{'finish_reason':'stop','message':{'content':json.dumps(v,ensure_ascii=False)}}]},ensure_ascii=False).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def log_message(self,*a):pass
service=ThreadingHTTPServer(('127.0.0.1',0),Mock);threading.Thread(target=service.serve_forever,daemon=True).start()
try:
    from pipeline import run
    cfg=json.loads((ROOT/'模型配置.json').read_text(encoding='utf-8'));cfg.update(url=f'http://127.0.0.1:{service.server_port}/chat/completions',model='mock-only',allow_insecure_localhost_for_tests=True,mock_simulation=True)
    print('本机模拟服务仅验证分页、协议和导出；不代表模型理解或拓扑质量。',flush=True)
    output=run(ROOT,cfg,'mock-only');report=json.loads((output/'处理校验报告.json').read_text(encoding='utf-8'))
    if Mock.maps!=report['input_facts_coverage']['fact_pages'] or Mock.merges<1:raise RuntimeError('模拟调用次数不符')
    if report['model_mode']!='mock' or not report['input_facts_coverage']['all_valid_edge_rows_paged_once']:raise RuntimeError('模拟模式或覆盖错误')
    print('模拟服务验证通过：',output,flush=True)
finally:service.shutdown();service.server_close()
