#!/usr/bin/env python3
"""Integration test using two local mock endpoints, not real model inference."""
import concurrent.futures,json,os,shutil,subprocess,sys,tempfile,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from openpyxl import Workbook
ROOT=Path(__file__).resolve().parent
class Mock(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.headers.get('Authorization')!='Bearer '+self.server.secret:self.send_error(401);return
        self.server.calls+=1
        req=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        if req['model']!=self.server.model:self.send_error(400);return
        data=json.loads(req['messages'][1]['content'])
        if 'page_id' in data:
            e=data['edges'];groups=[]
            if e:groups=[{'name':'测试分组','parents':[],'members':[e[0]['a'],e[0]['b']],'evidence_edge_ids':[e[0]['id']]}]
            v={'reviewed_nodes':[n['name'] for n in data['nodes']],'reviewed_edges':[x['id'] for x in e],'groups':groups}
        else:v={'reviewed_proposal_ids':[p['id'] for p in data['proposal_groups']],'operations':[]}
        blob=json.dumps({'model':self.server.model,'choices':[{'finish_reason':'stop','message':{'content':json.dumps(v,ensure_ascii=False)}}]},ensure_ascii=False).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(blob)));self.end_headers();self.wfile.write(blob)
    def log_message(self,*args):pass
servers=[]
try:
    for name in ('alpha','beta'):
        s=ThreadingHTTPServer(('127.0.0.1',0),Mock);s.secret='mock-secret-'+name;s.model='mock-'+name;s.calls=0;servers.append(s);threading.Thread(target=s.serve_forever,daemon=True).start()
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp);shutil.copytree(ROOT/'src',root/'src',ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copy2(ROOT/'启动验证.py',root/'启动验证.py')
        (root/'字段映射.json').write_text(json.dumps({'网元表':{'sheet':'网元','header_row':1},'链路表':{'sheet':'链路','header_row':1}},ensure_ascii=False),encoding='utf-8')
        w=Workbook();s=w.active;s.title='网元';s.append(['网元名称','网元角色']);s.append(['A','core']);s.append(['B','aggregation']);s.append(['C','access'])
        s=w.create_sheet('链路');s.append(['源网元名称','宿网元名称']);s.append(['A','B']);s.append(['B','C']);w.save(root/'input.xlsx')
        cfg={'url':'unused','model':'unused','api_key_env':'UNUSED','max_batch_chars':20000,'max_edges_per_batch':60,'max_parallel_model_calls':1,'allow_insecure_localhost_for_tests':True,'mock_simulation':True,'layout_refinement_iterations':0,'max_tokens':1000}
        (root/'模型配置.json').write_text(json.dumps(cfg),encoding='utf-8')
        profiles={}
        for name,server in zip(('alpha','beta'),servers):profiles[name]={'url':f'http://127.0.0.1:{server.server_port}/chat/completions','model':server.model,'api_key_env':'TEST_KEY_'+name.upper()}
        (root/'模型服务.json').write_text(json.dumps({'default_profile':'alpha','profiles':profiles}),encoding='utf-8')
        env=os.environ.copy();env.update(TEST_KEY_ALPHA=servers[0].secret,TEST_KEY_BETA=servers[1].secret)
        def command(*args):return subprocess.run([sys.executable,str(root/'启动验证.py'),*args],cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',timeout=60)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda n:command('--profile',n),('alpha','beta')))
        for result in results:
            if result.returncode:raise AssertionError(result.stdout+'\n'+result.stderr)
        outputs=[Path((root/'output'/f'最新运行目录_{p}.txt').read_text(encoding='utf-8').strip()) for p in ('alpha','beta')]
        assert outputs[0]!=outputs[1]
        for name,folder in zip(('alpha','beta'),outputs):
            assert folder.is_dir() and (folder/'整体网络拓扑.svg').exists() and (folder/'网元坐标与链路.xlsx').exists()
            assert json.loads((folder/'模型配置归属.json').read_text(encoding='utf-8'))['profile']==name
        before=[s.calls for s in servers];res=command('--profile','alpha','--resume')
        assert res.returncode==0 and [s.calls for s in servers]==before and '复用已完成' in res.stdout
        wrong=command('--profile','beta','--resume',str(outputs[0]))
        assert wrong.returncode!=0 and '不能续跑' in wrong.stderr
        for file in (root/'output').rglob('*'):
            if file.is_file() and file.suffix in ('.json','.txt','.svg','.html'):
                content=file.read_text(encoding='utf-8',errors='ignore')
                assert all(server.secret not in content for server in servers)
        sys.path.insert(0,str(root/'src'))
        from run_lock import locked_run
        with locked_run(outputs[0]):
            blocked=command('--profile','alpha','--resume',str(outputs[0]))
            assert blocked.returncode!=0 and '另一个进程' in blocked.stderr
        print('通过：两个模拟模型同时独立调用、密钥隔离、独立输出、按配置续跑、禁止跨配置续跑、目录锁。')
finally:
    for s in servers:s.shutdown();s.server_close()
