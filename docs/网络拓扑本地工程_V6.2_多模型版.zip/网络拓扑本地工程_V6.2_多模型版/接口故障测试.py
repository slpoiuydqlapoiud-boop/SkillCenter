#!/usr/bin/env python3
"""内存模拟异常响应，不发送任何真实请求。"""
import json,sys,tempfile
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'src'))
import model_api
class Response:
    status=200
    def __init__(self,obj):self.obj=obj
    def __enter__(self):return self
    def __exit__(self,*_):pass
    def read(self,*_):return json.dumps(self.obj,ensure_ascii=False).encode()
class Opener:
    def __init__(self,obj):self.obj=obj
    def open(self,*_,**__):return Response(self.obj)
cases=[({'choices':[{'finish_reason':'length','message':{'content':None,'reasoning_content':'模拟思考内容'}}]},'token 上限'),
       ({'choices':[{'finish_reason':'stop','message':{'content':None,'reasoning_content':'模拟思考内容'}}]},'message.content'),
       ({'choices':[{'finish_reason':'stop','message':{'content':'不符合JSON'}}]},'不是有效 JSON')]
old=model_api.urllib.request.build_opener
try:
    with tempfile.TemporaryDirectory() as t:
        out=Path(t);cfg={'url':'https://example.invalid/v1/chat/completions','model':'mock'}
        for response,expected in cases:
            model_api.urllib.request.build_opener=lambda *_,obj=response:Opener(obj)
            try:model_api.call(cfg,'synthetic-test-key',{'nodes':[]},out)
            except ValueError as e:
                if expected not in str(e):raise AssertionError(str(e))
            else:raise AssertionError('错误响应未报错')
            diagnostic=(out/'模型调用诊断.json').read_text(encoding='utf-8')
            assert 'synthetic-test-key' not in diagnostic and '模拟思考内容' not in diagnostic
    print('通过：输出长度截断、空内容、非 JSON、密钥与思考正文不进入诊断文件。')
finally:model_api.urllib.request.build_opener=old
