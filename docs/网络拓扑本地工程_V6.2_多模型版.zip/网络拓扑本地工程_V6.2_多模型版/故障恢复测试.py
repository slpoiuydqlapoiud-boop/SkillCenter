#!/usr/bin/env python3
"""仅在本机模拟模型 HTTP 故障与恢复；绝不评价模型语义能力。"""
import json,sys,threading,collections
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
class Service(BaseHTTPRequestHandler):
    fail=True;counts=collections.Counter()
    def do_POST(self):
        req=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        data=json.loads(req['messages'][1]['content']);pid=data.get('page_id','merge');Service.counts[pid]+=1
        if pid=='B0003' and Service.fail:
            self.send_error(503);return
        if 'page_id' in data:
            edges=data['edges'];groups=[]
            if edges and edges[0]['a']!=edges[0]['b']:
                e=edges[0];groups=[{'name':'测试组（模拟）','parents':[],'members':[e['a'],e['b']],'evidence_edge_ids':[e['id']]}]
            result={'groups':groups,'region_suggestions':[],'node_assessments':[],'backbone_suggestions':[]}
        else:result={'operations':[],'region_names':[],'backbone_nodes':[]}
        # 故意不返回 reviewed_*，模拟真实模型漏填自报字段。
        raw=json.dumps({'model':'test','choices':[{'finish_reason':'stop','message':{'content':json.dumps(result,ensure_ascii=False)}}]},ensure_ascii=False).encode()
        self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Service);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
    from pipeline import run
    cfg=json.loads((ROOT/'模型配置.json').read_text(encoding='utf-8'));cfg.update(url=f'http://127.0.0.1:{server.server_port}/chat/completions',model='mock-recovery',allow_insecure_localhost_for_tests=True,max_parallel_model_calls=1,layout_refinement_iterations=100)
    out=run(ROOT,cfg,'test-key')
    report=json.loads((out/'处理校验报告.json').read_text(encoding='utf-8'))
    assert report['model_run_incomplete'] and report['input_facts_coverage']['completed_fact_pages']==2
    assert '模型推理未完成' in (out/'整体网络拓扑.svg').read_text(encoding='utf-8')
    assert report['node_names']==1565 and report['valid_link_rows']==2535
    count_before=dict(Service.counts);Service.fail=False
    run(ROOT,cfg,'test-key',resume_dir=out)
    report=json.loads((out/'处理校验报告.json').read_text(encoding='utf-8'))
    assert not report['model_run_incomplete'] and report['input_facts_coverage']['completed_fact_pages']==report['input_facts_coverage']['fact_pages']
    assert not report['input_facts_coverage']['model_self_report_complete']
    assert '未逐项自报覆盖' in (out/'整体网络拓扑.svg').read_text(encoding='utf-8')
    assert Service.counts['B0001']==count_before['B0001'] and Service.counts['B0002']==count_before['B0002']
    assert (out/'整体网络拓扑_4K.png').exists() and not (out/'模型中断诊断.json').exists()
    print('通过：经典案例全量节点链路、故障预览、模型漏报、恢复复用、最终 SVG/PNG；未调用真实模型。',flush=True)
finally:server.shutdown();server.server_close()
