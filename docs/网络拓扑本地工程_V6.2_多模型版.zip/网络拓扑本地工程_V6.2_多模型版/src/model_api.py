import json, time, hashlib, urllib.error, urllib.parse, urllib.request
from pathlib import Path
PROMPT='请按输入事实输出 JSON，不得编造设备和链路。'

def write(path,obj):Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def call(cfg,token,evidence,out,prompt=None):
    u=urllib.parse.urlparse(cfg.get('url',''))
    if u.scheme!='https' and not (cfg.get('allow_insecure_localhost_for_tests') and u.scheme=='http' and u.hostname in ('localhost','127.0.0.1','::1')):raise ValueError('模型接口必须使用 HTTPS')
    request_body={'model':cfg['model'],'messages':[{'role':'system','content':prompt if prompt is not None else PROMPT},{'role':'user','content':json.dumps(evidence,ensure_ascii=False,separators=(',',':'))}],'temperature':cfg.get('temperature',0.1),'max_tokens':cfg.get('max_tokens',8192),'stream':False}
    fingerprint=hashlib.sha256(json.dumps({'url':cfg['url'],'body':request_body},ensure_ascii=False,sort_keys=True).encode('utf-8')).hexdigest()
    checkpoint=out/'调用完成检查点.json'
    if cfg.get('resume_model_calls',True) and checkpoint.exists():
        try:
            saved=json.loads(checkpoint.read_text(encoding='utf-8'))
            if saved.get('fingerprint')==fingerprint and isinstance(saved.get('result'),dict) and isinstance(saved.get('diagnostic'),dict):
                print('复用已完成的模型请求：'+str(out),flush=True)
                return saved['result'],saved['diagnostic']
        except (OSError,ValueError,TypeError):pass
    write(out/'模型请求_不含密钥.json',request_body)
    req=urllib.request.Request(cfg['url'],data=json.dumps(request_body,ensure_ascii=False).encode('utf-8'),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST')
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    start=time.monotonic()
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=cfg.get('timeout_seconds',180)) as r:
            status=r.status
            try:result=json.load(r)
            except (ValueError,UnicodeError):raise ValueError('接口响应不是有效 JSON，请检查地址、服务和代理') from None
    except urllib.error.HTTPError as e:
        hint=('检查 API Key 或权限' if e.code in (401,403) else '检查接口地址或模型名称' if e.code==404 else '服务限流，请降低并发并稍后恢复' if e.code==429 else '服务端暂不可用，请稍后恢复' if e.code>=500 else '检查请求参数、模型名称和额度')
        raise ValueError(f'模型接口返回 HTTP {e.code}；{hint}') from None
    except (urllib.error.URLError,TimeoutError,OSError) as e:raise ValueError('模型请求连接失败或超时（等待上限 '+str(cfg.get('timeout_seconds',600))+' 秒）；请检查接口地址、网络和超时配置。错误类型：'+type(e).__name__) from None
    if not isinstance(result,dict):raise ValueError('接口返回顶层不是 JSON 对象')
    choices=result.get('choices');choice=choices[0] if isinstance(choices,list) and choices and isinstance(choices[0],dict) else {};msg=choice.get('message') if isinstance(choice.get('message'),dict) else {};content=msg.get('content');reasoning=msg.get('reasoning_content');finish=choice.get('finish_reason')
    def usage_num(obj):
        return {str(k):usage_num(v) for k,v in obj.items() if isinstance(v,(dict,int,float)) and not isinstance(v,bool)} if isinstance(obj,dict) else obj
    diag={'status':status,'requested_model':cfg['model'],'returned_model':result.get('model'),'finish_reason':finish,'content_type':type(content).__name__,'content_characters':len(content) if isinstance(content,str) else None,'reasoning_content_characters':len(reasoning) if isinstance(reasoning,str) else None,'message_keys':list(msg)[:30],'usage':usage_num(result.get('usage',{})),'duration_seconds':round(time.monotonic()-start,2)}
    write(out/'模型调用诊断.json',diag)
    if isinstance(content,str) and content.strip():(out/'模型原始输出.txt').write_text(content,encoding='utf-8')
    if finish=='length':raise ValueError('模型输出达到 token 上限；请查看模型调用诊断.json，并检查 max_tokens')
    if finish not in (None,'stop'):raise ValueError(f'模型未正常结束，finish_reason={finish}；请看模型调用诊断.json')
    if not isinstance(content,str) or not content.strip():raise ValueError('模型 message.content 为空或不是文本；请查看模型调用诊断.json')
    content=content.strip()
    if content.startswith('```'):
        import re
        content=re.sub(r'^```(?:json)?\s*','',content,flags=re.I);content=re.sub(r'\s*```$','',content)
    try:plan=json.loads(content)
    except ValueError:raise ValueError('模型最终内容不是有效 JSON；请查看模型原始输出.txt') from None
    if not isinstance(plan,dict):raise ValueError('模型返回的布局规划必须是 JSON 对象')
    temp=out/'调用完成检查点.tmp'
    write(temp,{'fingerprint':fingerprint,'result':plan,'diagnostic':diag});temp.replace(checkpoint)
    return plan,diag
