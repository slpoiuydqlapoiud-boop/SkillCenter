"""节点圆点占位检查：允许同一真实父网元的单邻居组交叠。"""
import collections,math

def audit(nodes,clusters):
    parent={n:c['parent'] for c in clusters for n in c['members']};grid=collections.defaultdict(list);allowed=0;problems=[];foreign=0
    def radius(n):return 13 if n.get('is_backbone') else {'core':9,'aggregation':7,'access':4,'other':3,'server':2.4,'ap':2.4}[n['role']]
    for name,n in nodes.items():
        x,y=n['x'],n['y'];r=radius(n)
        if not (math.isfinite(x) and math.isfinite(y) and 0<=x<=3200 and 0<=y<=1800):raise ValueError('网元坐标超出画布或无效：'+name)
        gx,gy=int(x//32),int(y//32)
        for i in range(gx-1,gx+2):
            for j in range(gy-1,gy+2):
                for other,ox,oy,rr in grid[(i,j)]:
                    if (x-ox)**2+(y-oy)**2<(r+rr)**2-1e-6:
                        if parent.get(name) is not None and parent.get(name)==parent.get(other):allowed+=1
                        else:
                            foreign+=1
                            if len(problems)<30:problems.append({'a':name,'b':other,'distance':round(math.hypot(x-ox,y-oy),2),'required':r+rr})
        grid[(gx,gy)].append((name,x,y,r))
    return {'method':'按绘制半径检查圆点相交；同父单邻居组相交允许','allowed_same_parent_overlap_pairs':allowed,'unrelated_overlap_pairs':foreign,'unrelated_examples':problems}
