"""OS-level advisory lock: released even if the process terminates."""
import os
from contextlib import contextmanager

@contextmanager
def locked_run(path):
    f=open(path/'运行目录.lock','a+b')
    f.seek(0,os.SEEK_END)
    if f.tell()==0:f.write(b'0');f.flush()
    f.seek(0)
    try:
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:raise RuntimeError('此结果目录正由另一个进程使用；请等待它结束或选择其他 --resume 目录') from None
        try:yield
        finally:
            if os.name=='nt':
                import msvcrt
                f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_UN)
    finally:f.close()
