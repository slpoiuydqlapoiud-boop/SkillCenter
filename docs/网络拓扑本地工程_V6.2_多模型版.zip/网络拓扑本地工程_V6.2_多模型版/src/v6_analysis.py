"""V6: page raw topology facts; only model responses propose groups."""
import collections,copy,json,math,concurrent.futures,itertools
from pathlib import Path
from model_api import call,write

MAP_PROMPT='''你是网络架构与运维专家。输入是一页来自Excel的真实网元与链路事实，不含程序预先计算的局部组。请自主识别这页中有证据的局部组网，例如核心互联、双/单上联、多父节点、Spine-Leaf、分支或设备族；不要被这些例子限制，不得编造节点或链路。输出纯JSON：{"reviewed_nodes":["输入的每个nodes.name原样列出"],"reviewed_edges":["输入的每个edges.id原样列出"],"groups":[{"name":"局部结构名称","parents":["可为空，上联网元名称"],"members":["真实网元名称"],"evidence_edge_ids":["输入中的真实链路ID"],"kind":"结构描述","reason":"根据名称、角色、端口、带宽、实际邻接的判断及不确定性","relative_depth":"auto","priority":"normal","position_x":0.5,"layout_kind":"grid","space_weight":1.0}],"region_suggestions":[{"name":"区域名称","members":["本页真实名称"],"position_x":0.5,"reason":"依据"}],"node_assessments":[{"name":"本页网元名称","role":"core/aggregation/access/other/unknown","region_id":"占位区域ID或unknown","reason":"判断与不确定性"}],"backbone_suggestions":["本页真实名称"],"uncertainties":["未知/缺少上下文"]}。必须逐一回传本页全部reviewed_nodes和reviewed_edges，表示已接收，不代表推理一定正确；members包括属于组的节点，parents可为空，成员可跨组和重叠。region_suggestions为模型自主提出的大区与本页成员；相同区域在不同页尽量使用完全相同的名称；position_x是相对横向顺序。只引用本页nodes与edges。不要输出Markdown；不能确认时留空并注明不确定。'''
MERGE_PROMPT='''你是网络拓扑规划专家。输入是模型基于原始事实提出的局部组，程序未预先计算局部组；本次仅处理传入的这批候选。请独立判断哪些候选实际上是同一个组，可给出合并操作，不要把只相邻、上下层或共享少量节点的组强行合并。未出现在操作中的组原样保留。输出纯JSON：{"reviewed_proposal_ids":["本批全部proposal id"],"operations":[{"op":"merge","ids":["P0001","P0002"],"name":"合并后名称","reason":"判断依据和不确定性","relative_depth":"auto","priority":"normal","position_x":0.5,"layout_kind":"grid","space_weight":1.0}],"region_names":[{"id":"R01","name":"区域名称","anchor_x":0.2,"reason":"依据"}],"backbone_nodes":["提供的真实网元名"],"analysis":"判断及未解决问题"}。reviewed_proposal_ids必须逐一列出本批全部proposal id，表示已接收，不代表推理一定正确；ids只可从本批proposal id中选择，不能发明节点和链路；若无法确定，operations填空数组。区域占位仅供布局，不等于已确认业务区。'''

def pages(nodes,edges,max_edges=180,max_chars=115000):
    if not 1<=max_edges<=1000 or not 10000<=max_chars<=500000:raise ValueError('分页参数超出允许范围')
    def fact(name):
        n=nodes[name];return {'name':name,'ip':n.get('ip',''),'inventory_role':n.get('raw_role',''),'inventory_region':n.get('raw_region',''),'device_type':n.get('device_type',''),'in_inventory':n.get('known',False),'source_inventory_records':n.get('source_inventory_records') or ([{'row':None,'attributes':n.get('source_attributes',{})}] if n.get('source_attributes') else [])}
    def pack(es,extra=()):
        names=sorted({x for e in es for x in (e['a'],e['b'])}|set(extra))
        return {'nodes':[fact(n) for n in names],'edges':es}
    records=[{'id':f'L{i:07d}','a':e['a'],'b':e['b'],'a_port':e.get('a_port',''),'b_port':e.get('b_port',''),'link_type':e.get('type',''),'bandwidth_m':e.get('bandwidth',''),'source_sheet':e['sheet'],'source_row':e['row'],'source_attributes':e.get('source_attributes',{})} for i,e in enumerate(edges,1)]
    chunks=[];current=[]
    def size(v):return len(json.dumps(v,ensure_ascii=False,separators=(',',':')))
    for e in records:
        proposed=current+[e]
        if current and (len(proposed)>max_edges or size(pack(proposed))>max_chars):chunks.append(pack(current));current=[e]
        else:current=proposed
        if size(pack(current))>max_chars:raise ValueError('单条链路与端点信息超过模型输入长度限制，请调整配置或清理输入')
    if current:chunks.append(pack(current))
    involved={v for e in records for v in (e['a'],e['b'])};isolated=sorted(set(nodes)-involved)
    while isolated:
        part=[]
        while isolated and len(part)<max_edges and size(pack([],part+[isolated[0]]))<=max_chars:part.append(isolated.pop(0))
        if not part:raise ValueError('单个网元信息超过模型输入长度限制')
        chunks.append(pack([],part))
    if not chunks:chunks=[pack([],sorted(nodes))]
    for i,c in enumerate(chunks,1):c['page_id']=f'B{i:04d}'
    return chunks

def _as_names(items):return {x for x in items if isinstance(x,str)} if isinstance(items,list) else set()

def run_maps(cfg,token,chunks,out):
    proposals=[];results=[];rejected=[];backs=[];region_suggestions=[];assessments=[]
    partial_error=None
    parallel=int(cfg.get('max_parallel_model_calls',2))
    if not 1<=parallel<=8:raise ValueError('max_parallel_model_calls范围为1至8')
    def invoke(item):
        i,chunk=item;pid=chunk['page_id'];d=out/'模型分批'/pid;d.mkdir(parents=True,exist_ok=True)
        print(f'模型事实页 {i}/{len(chunks)}：{len(chunk["nodes"])} 网元、{len(chunk["edges"])} 条源链路',flush=True)
        expected_nodes={n['name'] for n in chunk['nodes']};expected_edges={e['id'] for e in chunk['edges']}
        retries=int(cfg.get('max_review_retries',1))
        if not 0<=retries<=2:raise ValueError('max_review_retries范围为0至2')
        missing_nodes=set();missing_edges=set()
        for attempt in range(retries+1):
            sub=d/f'A{attempt+1:02d}';sub.mkdir(exist_ok=True)
            payload=dict(chunk)
            if attempt:payload['review_correction']={'previous_missing_nodes':sorted(missing_nodes),'previous_missing_edges':sorted(missing_edges),'instruction':'请检查整页并在本次完整输出全部已检查网元和链路，不仅是遗漏项'}
            result,diag=call(cfg,token,payload,sub,prompt=MAP_PROMPT);write(sub/'模型解析结果.json',result)
            if not isinstance(result.get('groups',[]),list):raise ValueError(pid+' 的 groups 不是数组，无法使用该页模型结果')
            missing_nodes=expected_nodes-_as_names(result.get('reviewed_nodes'));missing_edges=expected_edges-_as_names(result.get('reviewed_edges'))
            write(sub/'覆盖检查.json',{'missing_nodes':sorted(missing_nodes),'missing_edges':sorted(missing_edges)})
            if (not missing_nodes and not missing_edges) or not cfg.get('strict_model_coverage',False):write(d/'模型解析结果.json',result);return chunk,result,diag
        raise ValueError(f'{pid} 模型连续{retries+1}次未列出所有已检查项，已停止；请看模型分批目录')
    # Independent calls may be parallel; process results in page order for deterministic IDs.
    with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as pool:
      pending=[pool.submit(invoke,item) for item in enumerate(chunks,1)]
      for task in pending:
        try:chunk,result,diag=task.result()
        except Exception as exc:
            for remaining in pending:remaining.cancel()
            partial_error={'page_id':chunks[len(results)]['page_id'],'error_type':type(exc).__name__,'message':str(exc),'completed_pages':len(results),'total_pages':len(chunks)}
            write(out/'模型中断诊断.json',partial_error)
            print('模型处理未完成：'+str(exc)+'；将导出明确标记的未完成预览。',flush=True)
            break
        pid=chunk['page_id']
        expected_nodes={x['name'] for x in chunk['nodes']};expected_edges={x['id'] for x in chunk['edges']};review_nodes=_as_names(result.get('reviewed_nodes'));review_edges=_as_names(result.get('reviewed_edges'))
        missing_nodes=expected_nodes-review_nodes;missing_edges=expected_edges-review_edges
        results.append({'page_id':pid,'nodes_sent':len(expected_nodes),'edges_sent':len(expected_edges),'nodes_model_reported_reviewed':len(expected_nodes&review_nodes),'edges_model_reported_reviewed':len(expected_edges&review_edges),'missing_nodes':sorted(missing_nodes),'missing_edges':sorted(missing_edges),'diagnostic':diag})
        write(out/'模型覆盖进度.json',results)
        if (missing_nodes or missing_edges) and cfg.get('strict_model_coverage',False):
            for remaining in pending:remaining.cancel()
            raise ValueError(f'{pid} 模型未列出所有已检查网元/链路，已停止；请查看模型覆盖进度.json，可调整每页大小后重试')
        groups=result.get('groups',[])
        if not isinstance(groups,list):raise ValueError(pid+' 的 groups 不是数组')
        for g in groups:
            if not isinstance(g,dict):rejected.append({'page_id':pid,'reason':'组不是对象'});continue
            members=g.get('members',[]);parents=g.get('parents',[]);evidence=g.get('evidence_edge_ids',[])
            if not isinstance(members,list) or not isinstance(parents,list) or not isinstance(evidence,list) or not all(isinstance(n,str) and n in expected_nodes for n in members+parents) or not all(isinstance(e,str) and e in expected_edges for e in evidence):
                rejected.append({'page_id':pid,'reason':'成员或引用链路不在该页事实中','proposal':g});continue
            g=copy.deepcopy(g);g['id']=f'P{len(proposals)+1:06d}';g['source_page']=pid;proposals.append(g)
        assessments.extend(x for x in result.get('node_assessments',[]) if isinstance(x,dict) and isinstance(x.get('name'),str) and x.get('name') in expected_nodes) if isinstance(result.get('node_assessments',[]),list) else None
        backs.extend(x for x in result.get('backbone_suggestions',[]) if isinstance(x,str) and x in expected_nodes) if isinstance(result.get('backbone_suggestions',[]),list) else None
        proposed_regions=result.get('region_suggestions',[])
        if isinstance(proposed_regions,list):
            for x in proposed_regions:
                if not isinstance(x,dict) or not isinstance(x.get('name'),str) or not x['name'].strip() or not isinstance(x.get('members'),list) or not x['members'] or not all(isinstance(n,str) and n in expected_nodes for n in x['members']):
                    rejected.append({'page_id':pid,'reason':'区域名称无效或成员不在事实页','proposal':x});continue
                x=dict(x);x['source_page']=pid;region_suggestions.append(x)
    return proposals,results,rejected,backs,region_suggestions,assessments,partial_error

def apply_merges(proposals,operations):
    index={p['id']:p for p in proposals};used=set();created=[];rejected=[]
    if not isinstance(operations,list):return proposals,[{'reason':'合并操作不是数组'}]
    for op in operations:
        if not isinstance(op,dict) or op.get('op')!='merge' or not isinstance(op.get('ids'),list):rejected.append({'reason':'合并操作格式错误','value':op});continue
        ids=op['ids']
        if len(ids)<2 or any(not isinstance(i,str) or i not in index or i in used for i in ids) or len(set(ids))!=len(ids):rejected.append({'reason':'合并ID不存在或重复使用','value':op});continue
        name=op.get('name');
        if not isinstance(name,str) or not name.strip():rejected.append({'reason':'合并组缺少名称','value':op});continue
        part=[index[i] for i in ids];g={'id':'M'+str(len(created)+1).zfill(6),'name':name[:80],'members':sorted(set(n for x in part for n in x.get('members',[]))),'parents':sorted(set(n for x in part for n in x.get('parents',[]))),'evidence_edge_ids':sorted(set(e for x in part for e in x.get('evidence_edge_ids',[]))),'kind':'模型归并组','reason':str(op.get('reason',''))[:500],'merged_from':ids,'source_page':'model_merge','relative_depth':op.get('relative_depth','auto'),'priority':op.get('priority','normal'),'position_x':op.get('position_x'),'layout_kind':op.get('layout_kind','grid'),'space_weight':op.get('space_weight',1.0),'layout_fields_from_model':[k for k in ('relative_depth','priority','position_x','layout_kind','space_weight') if k in op]}
        used.update(ids);created.append(g)
    return [p for p in proposals if p['id'] not in used]+created,rejected

def run_merge(cfg,token,proposals,region_hints,backs,region_suggestions,out,adj,fact_nodes,fact_edges):
    """The model compares every proposal pair via block pairs and adjudicates transitive merges.

    The code only applies explicit model merge decisions and validates real
    connectivity; it never identifies candidate local groups itself.
    """
    if not proposals:
        return [],{'calls':[],'pairwise_model_batches':0,'cross_page_merge_not_evaluated':False,'rejected':[],'note':'模型未提出可保留的局部组'},[],[]
    limit=int(cfg.get('merge_groups_per_batch',40));max_pairs=int(cfg.get('max_merge_pair_batches',120))
    if not 2<=limit<=120 or not 1<=max_pairs<=10000:raise ValueError('归并参数超出范围')
    if len(proposals)<=limit:blocks=[proposals]
    else:
        block_size=max(1,limit//2);blocks=[proposals[i:i+block_size] for i in range(0,len(proposals),block_size)]
    block_pairs=list(itertools.combinations_with_replacement(range(len(blocks)),2))
    if len(block_pairs)>max_pairs:raise ValueError(f'完整跨页比较需要{len(block_pairs)}次模型请求，超过 max_merge_pair_batches={max_pairs}；已保留模型事实页结果，请调整容量或配置')
    byid={x['id']:x for x in proposals};proposed_ops=[];rejected=[];calls=[];region_plans=[];backbones=[]
    max_chars=int(cfg.get('max_merge_input_chars',220000))
    def connected_sets(sets):
        if not sets:return False
        seen={0};stack=[0]
        while stack:
            i=stack.pop()
            for j in range(len(sets)):
                if j not in seen and (bool(sets[i]&sets[j]) or any(y in adj.get(x,set()) for x in sets[i] for y in sets[j])):
                    seen.add(j);stack.append(j)
        return len(seen)==len(sets)
    def invoke(part,tag,extra=None):
        d=out/'模型归并'/tag;d.mkdir(parents=True,exist_ok=True)
        names={n for g in part for n in g.get('members',[])+g.get('parents',[])}
        claimed_ids={eid for g in part for eid in g.get('evidence_edge_ids',[])}
        relevant_edges=[e for e in fact_edges if (e['a'] in names and e['b'] in names) or e['id'] in claimed_ids]
        names.update(n for e in relevant_edges for n in (e['a'],e['b']))
        inp={'proposal_groups':part,'nodes':[fact_nodes[n] for n in sorted(names) if n in fact_nodes],'edges':relevant_edges,'layout_region_hints':region_hints,'model_backbone_suggestions':sorted(set(backs)),'model_region_suggestions':region_suggestions,'note':'仅基于本次提供的模型组和原始事实比较；未提及的组保留'}
        if extra is not None:inp['prior_model_merge_suggestions']=extra;inp['note']='请复核这些可能存在传递冲突的合并建议，只输出你确认应当合并的组，未提及的组保留'
        if len(json.dumps(inp,ensure_ascii=False))>max_chars:raise ValueError('归并输入超长；请减小 merge_groups_per_batch 或调整 max_merge_input_chars；已保留事实页结果')
        expected={g['id'] for g in part};retries=int(cfg.get('max_review_retries',1));missing=set()
        for attempt in range(retries+1):
            ad=d/f'A{attempt+1:02d}';ad.mkdir(exist_ok=True);payload=dict(inp)
            if attempt:payload['review_correction']={'missing_proposal_ids':sorted(missing),'instruction':'请复核整页，并列出本批全部 reviewed_proposal_ids'}
            raw,diag=call(cfg,token,payload,ad,prompt=MERGE_PROMPT);write(ad/'模型解析结果.json',raw)
            missing=expected-_as_names(raw.get('reviewed_proposal_ids'));write(ad/'覆盖检查.json',{'missing_proposal_ids':sorted(missing)})
            if not missing or not cfg.get('strict_model_coverage',False):write(d/'模型解析结果.json',raw);break
        else:raise ValueError(f'{tag} 模型未列出全部已比较组，已停止；请查看模型归并目录')
        region_plans.extend(raw.get('region_names',[]) if isinstance(raw.get('region_names',[]),list) else [])
        backbones.extend(raw.get('backbone_nodes',[]) if isinstance(raw.get('backbone_nodes',[]),list) else [])
        calls.append({'page':tag,'input_groups':len(part),'model_missing_proposal_ids':sorted(missing),'diagnostic':diag})
        return raw.get('operations',[])
    for i,(left,right) in enumerate(block_pairs,1):
        part=blocks[left] if left==right else blocks[left]+blocks[right]
        print(f'模型跨页比较 {i}/{len(block_pairs)}：{len(part)} 个模型组',flush=True)
        operations=invoke(part,f'C{i:04d}');allowed={g['id'] for g in part}
        if not isinstance(operations,list):rejected.append({'page':i,'reason':'合并操作不是数组'});continue
        for op in operations:
            ids=op.get('ids') if isinstance(op,dict) else None
            if not isinstance(op,dict) or op.get('op')!='merge' or not isinstance(ids,list) or len(ids)<2 or any(not isinstance(x,str) or x not in allowed for x in ids) or len(set(ids))!=len(ids) or not isinstance(op.get('name'),str) or not op['name'].strip():
                rejected.append({'page':i,'reason':'合并操作无效或引用非本页组','value':op});continue
            # Basic evidence check: each proposal in a merge must connect to another
            # through a shared actual member or an actual edge. This does not infer groups.
            sets=[set(byid[x].get('members',[])+byid[x].get('parents',[])) for x in ids]
            ok=connected_sets(sets)
            if not ok:op=dict(op);op['evidence_warning']='组之间未发现可核验的共享网元或直接连边，须专家确认'
            proposed_ops.append(op)
    # Build components of explicit model merge suggestions; no new grouping is inferred.
    link={i:i for i in byid}
    def find(i):
        while link[i]!=i:link[i]=link[link[i]];i=link[i]
        return i
    for op in proposed_ops:
        for other in op['ids'][1:]:link[find(other)]=find(op['ids'][0])
    comps=collections.defaultdict(list)
    for n in byid:comps[find(n)].append(n)
    approved=[]
    for k,ids in enumerate(comps.values(),1):
        related=[op for op in proposed_ops if set(op['ids'])<=set(ids)]
        if len(ids)<2 or not related:continue
        if len(ids)==2:approved.append(related[0]);continue
        if len(ids)>limit:raise ValueError(f'模型提出互相关联的归并分量含{len(ids)}组，超过单次复核容量；已保存中间结果')
        print(f'模型复核关联归并：{len(ids)} 个候选组',flush=True)
        ops=invoke([byid[x] for x in ids],f'A{k:04d}',related)
        if not isinstance(ops,list):rejected.append({'reason':'复核合并操作不是数组','ids':ids});continue
        # Revalidation and conflict handling done by apply_merges below.
        for op in ops:
            selected=op.get('ids') if isinstance(op,dict) else None
            if not isinstance(selected,list) or not all(isinstance(x,str) and x in ids for x in selected):rejected.append({'reason':'复核时引用了不在该复核页的组','value':op});continue
            approved.append(op)
    result,bad=apply_merges(proposals,approved);rejected.extend(bad)
    # Validate each final merged group against real source edges between the exact
    # constituent proposals, preserving source proposals on unsupported merges.
    verified=[]
    for g in result:
        ids=g.get('merged_from',[])
        if ids:
            sets=[set(byid[x].get('members',[])+byid[x].get('parents',[])) for x in ids]
            connected=connected_sets(sets)
            if not connected:
                g['merge_evidence_warning']='复核后的归并缺少组间共享网元或直接连边，须专家确认'
        verified.append(g)
    return verified,{'calls':calls,'pairwise_model_batches':len(block_pairs),'pairwise_proposal_coverage':'每对模型组至少同时出现在一次比较请求中；不证明模型判断正确','cross_page_merge_not_evaluated':False,'rejected':rejected},region_plans,backbones

def validate_groups(proposals,nodes,adj,region,edge_lookup=None):
    accepted=[];rejected=[]
    for p in proposals:
        name=p.get('name');members=p.get('members',[]);parents=p.get('parents',[])
        if not isinstance(name,str) or not name.strip() or not isinstance(members,list) or not isinstance(parents,list) or any(not isinstance(n,str) or n not in nodes for n in members+parents):rejected.append({'proposal':p,'reason':'组名或成员无效'});continue
        allnames=sorted(set(members+parents))
        if len(allnames)<2:rejected.append({'proposal':p,'reason':'组少于两个不同网元'});continue
        inside=sum(1 for a in allnames for b in adj[a] if b in allnames)//2
        shared=collections.Counter(q for n in allnames for q in adj[n] if q not in allnames)
        unsupported=[]
        for n in allnames:
            if adj[n]&set(allnames):continue
            if not any(adj[n]&adj[other] for other in allnames if other!=n):unsupported.append(n)
        claimed=p.get('evidence_edge_ids',[]) if isinstance(p.get('evidence_edge_ids',[]),list) else []
        unrelated=[eid for eid in claimed if edge_lookup is not None and (eid not in edge_lookup or not ({edge_lookup[eid]['a'],edge_lookup[eid]['b']} & set(allnames)))]
        # An unconnected business group can be a model hypothesis, but is never
        # portrayed as verified; individual unsupported members are explicit.
        rr=collections.Counter(region[n] for n in allnames);group=copy.deepcopy(p);group['name']=name.strip()[:80];group['members']=sorted(set(members));group['parents']=sorted(set(parents));group['all_members']=allnames;group['region_hint']=rr.most_common(1)[0][0];group['crosses_layout_regions']=len(rr)>1;group['verification']={'real_internal_pairs':inside,'shared_external_neighbor_exists':any(v>=2 for v in shared.values()),'members_without_local_evidence':unsupported,'unrelated_or_missing_evidence_ids':unrelated,'needs_expert_review':bool(unsupported or unrelated or p.get('merge_evidence_warning')),'meaning':'仅检查可见连接证据；无证据成员或归并未被删除，但必须专家确认；不证明业务分区'}
        accepted.append(group)
    return accepted,rejected
