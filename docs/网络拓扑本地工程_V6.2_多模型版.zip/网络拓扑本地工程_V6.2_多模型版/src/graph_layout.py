import collections, math, re, heapq

def classify(n):
    raw=(n.get('raw_role') or '').strip().lower(); name=n['name'].lower()
    # Explicit inventory role wins over naming; the same word may be a location or legacy name.
    if raw and raw not in ('-','--','未知','无'):
        if re.search(r'^(core|spine)$|核心|骨干',raw):return 'core','原网元表角色'
        if re.search(r'^(agg|aggregation)$|汇聚',raw):return 'aggregation','原网元表角色'
        if re.search(r'^(acc|access|leaf|fex)$|接入',raw):return 'access','原网元表角色'
        if re.search(r'^(fw|firewall)$|防火墙',raw):return 'other','原网元表角色'
    if re.search(r'(^|[-_])(core|spine|backbone)([-_]|\d|$)|核心|骨干',name):return 'core','名称规则推断'
    if re.search(r'(^|[-_])(agg|aggregation)([-_]|\d|$)|汇聚',name):return 'aggregation','名称规则推断'
    if re.search(r'(^|[-_])(acc|access|leaf|fex)([-_]|\d|$)|接入',name):return 'access','名称规则推断'
    if re.search(r'(^|[-_:])(server|srv|ser)([-_:]|\d|$)|服务器',name):return 'server','名称规则推断，待确认'
    if re.search(r'(^|[-_:])ap([-_:]|\d|$)|无线ap',name):return 'ap','名称规则推断，待确认'
    return 'other','未知角色'

def token_region(name, explicit):
    tokens=[s for s in re.split(r'[-_]',name.upper()) if s]
    for t in tokens[:3]:
        if t in explicit:return t
    return None

def is_management(e):return bool(re.search(r'(?i)mgmt|meth|management',e.get('a_port','')+' '+e.get('b_port','')))

def analyze(nodes,edges,max_regions=8):
    adj={n:set() for n in nodes};data_adj={n:set() for n in nodes};pairs=collections.defaultdict(list)
    for e in edges:
        a,b=e['a'],e['b'];adj[a].add(b);adj[b].add(a);pairs[tuple(sorted((a,b)))].append(e)
        if not is_management(e):data_adj[a].add(b);data_adj[b].add(a)
    for name,n in nodes.items():
        n['role'],n['role_basis']=classify(n);n['degree']=len(adj[name]-{name});n['data_degree']=len(data_adj[name]-{name})
        n['network_device']=bool(n['known'] or n['role'] in ('core','aggregation','access') or re.search(r'(?i)(^|[-_])(fw|router|switch|switcher)([-_]|\d|$)',name))
    hubs={n for n in nodes if nodes[n]['network_device']}
    # Ensure every graph component has an anchor, including isolated unknown devices.
    seen=set()
    for start in sorted(nodes):
        if start in seen:continue
        stack=[start];seen.add(start);component=[]
        while stack:
            n=stack.pop();component.append(n)
            for q in adj[n]:
                if q not in seen:seen.add(q);stack.append(q)
        if not any(n in hubs for n in component):
            anchor=min(component,key=lambda n:(-nodes[n]['degree'],n));hubs.add(anchor);nodes[anchor]['network_device']=True;nodes[anchor]['component_anchor']=True
    # A well-populated original region field is the highest-confidence grouping clue.
    raw=collections.Counter(n['raw_region'].strip().upper() for n in nodes.values() if n['raw_region'].strip() not in ('','-','--','未知','无','IP'))
    labels=[k for k,v in raw.most_common() if v>=2][:max_regions]
    region={}
    if len(labels)>=2:
        for n,v in nodes.items():
            key=v['raw_region'].strip().upper()
            if key not in labels:key=token_region(n,set(labels))
            if key in labels:region[n]=key
    else:
        # Fallback to repeated initial site-name tokens; avoid roles, generic prefixes, serials and MACs.
        stop={'NE','SW','RT','IP','LAN','WAN','DC','CORE','AGG','ACC','SPINE','LEAF','SERVER','NODE','NETWORK'}
        def prefix(n):
            ts=[t for t in re.split(r'[-_]',n.upper()) if t]; ts=[t for t in ts[:2] if t not in stop and re.fullmatch(r'[A-Z][A-Z0-9]{1,8}',t)]
            return ts[0] if ts else None
        seed_nodes=[n for n in hubs if nodes[n]['known']] or list(hubs)
        threshold=max(3,math.ceil(len(seed_nodes)*.03))
        raw=collections.Counter(prefix(n) for n in seed_nodes if prefix(n)); labels=[k for k,v in raw.most_common() if v>=threshold][:max_regions]
        if len(labels)>=2:
            for n in nodes:
                k=prefix(n)
                if k in labels:region[n]=k
    if len(set(region.values()))<2:
        # Disconnected components are candidates; a single network stays a single region.
        seen=set();components=[]
        for n in sorted(nodes):
            if n in seen:continue
            stack=[n];seen.add(n);component=[]
            while stack:
                u=stack.pop();component.append(u)
                for v in adj[u]:
                    if v not in seen:seen.add(v);stack.append(v)
            components.append(component)
        components.sort(key=lambda x:(-len(x),min(x)))
        region={n:'网络'+str(min(i,max_regions-1)+1) for i,comp in enumerate(components) for n in comp}
    # Propagate only from actual neighbours. Assign unresolved disconnected nodes to an explicit unassigned region.
    for _ in range(12):
        updates={}
        for n in nodes:
            if n in region:continue
            votes=collections.Counter(region[q] for q in adj[n] if q in region)
            if votes:updates[n]=min(votes,key=lambda x:(-votes[x],x))
        region.update(updates)
        if not updates:break
    if len(set(region.values()))>=max_regions:
        # Keep a separate trace label if possible; otherwise attach only by strongest name-independent count.
        default=min(collections.Counter(region.values()),key=lambda x:(-sum(1 for v in region.values() if v==x),x))
    else:default='未识别区域'
    for n in nodes:
        if n not in region:region[n]=default;nodes[n]['region_unresolved']=True
    sorted_labels=sorted(set(region.values()),key=lambda x:(x=='未识别区域',x))
    idmap={label:f'R{i+1:02}' for i,label in enumerate(sorted_labels)}
    for n in nodes:nodes[n]['region_hint']=region[n];region[n]=idmap[region[n]]
    # Retain internal facts used by the layout, without pretending they came from the LLM.
    for n in nodes:nodes[n]['data_neighbors']=sorted(data_adj[n])
    return adj,pairs,hubs,region

def place(nodes,adj,hubs,region,info,refine_iterations=2500,structural_groups=None,model_clusters=None):
    # Allocate major regions in a horizontal strip; the global backbone lives above all regions.
    ids=sorted(info,key=lambda k:(info[k]['anchor'] is None,info[k]['anchor'] or [0,0],k));count=len(ids)
    W,H=3200,1800;left,right=55,3145
    counts=collections.Counter(region.values());base=min(185,(right-left)/count*.45)
    weights={rid:math.sqrt(counts[rid]) for rid in ids};available=(right-left)-base*count;total=sum(weights.values())
    boxes={};cursor=left
    for rid in ids:
        width=base+available*weights[rid]/total;boxes[rid]=[cursor+12,365,cursor+width-12,1700];cursor+=width
    cross=collections.Counter()
    for a in hubs:
        for b in nodes[a]['data_neighbors']:
            if b in hubs and region[a]!=region[b]:cross[a]+=1
    roots={};network_pos={};clusters=[];subboxes=[]
    for rid in ids:
        members=[n for n in hubs if region[n]==rid]
        cand=sorted((n for n in members if cross[n]>0),key=lambda n:(nodes[n]['role']!='core',-cross[n],-nodes[n]['data_degree'],n))
        actual=[n for n in cand if nodes[n]['role']=='core']
        suggested=[n for n in info[rid].get('model_backbone_nodes',[]) if n in members and nodes[n]['data_degree']>0]
        chosen=suggested[:4] if suggested else (actual[:4] if actual else cand[:2])
        if not chosen:
            ordered=sorted((n for n in members if nodes[n]['data_degree']>0),key=lambda n:(nodes[n]['role']!='core',nodes[n]['role']!='aggregation',-nodes[n]['data_degree'],n));chosen=ordered[:min(2,len(ordered))]
        chosen.sort();roots[rid]=chosen
        for n in members:nodes[n]['is_backbone']=n in chosen
        x0,y0,x1,y1=boxes[rid];lo=x0+30;hi=x1-30
        for i,n in enumerate(chosen):network_pos[n]=(lo+(i+1)*(hi-lo)/(len(chosen)+1),305.0)
        dist={n:0 for n in chosen};queue=collections.deque(chosen)
        while queue:
            n=queue.popleft()
            for q in nodes[n]['data_neighbors']:
                if q in hubs and region[q]==rid and q not in dist:
                    dist[q]=dist[n]+1;queue.append(q)
        # Saturate very deep graphs into the final layer; retain true distance as metadata.
        layers=collections.defaultdict(list)
        for n in members:
            nodes[n]['backbone_distance']=dist.get(n)
            if n in chosen:continue
            layers[min(dist[n],7) if n in dist else 8].append(n)
        # Order each layer according to positions of preceding real neighbors.
        # Dense access groups are wrapped in rows; rank is based on their upstream barycenter.
        maxcols=max(2,min(12,int((hi-lo)//54)))
        units=sum(max(1,math.ceil(len(v)/maxcols)) for v in layers.values());units=max(1,units)
        step=min(95.0,1130/units); y=450.0
        for level in sorted(layers):
            ns=layers[level]
            def rank(n):
                p=[network_pos[q][0] for q in nodes[n]['data_neighbors'] if q in network_pos and region[q]==rid]
                return (sum(p)/len(p) if p else (lo+hi)/2,{'core':0,'aggregation':1,'access':2,'other':3,'server':4,'ap':5}.get(nodes[n]['role'],5),n)
            ns.sort(key=rank);cols=min(maxcols,len(ns));rows=math.ceil(len(ns)/cols)
            if level==8:y=max(y, max(1100,1650-rows*step))
            # Match slots to the real upstream-neighbor barycenter instead of filling each row mechanically.
            available=[((lo+hi)/2 if cols==1 else lo+(hi-lo)*c/(cols-1), y+r*step) for r in range(rows) for c in range(cols)]
            for n in ns:
                parent_x=[network_pos[q][0] for q in nodes[n]['data_neighbors'] if q in network_pos and region[q]==rid]
                wanted=sum(parent_x)/len(parent_x) if parent_x else (lo+hi)/2
                k=min(range(len(available)),key=lambda i:((available[i][0]-wanted)**2+0.16*(available[i][1]-y)**2,available[i][1],available[i][0]))
                network_pos[n]=available.pop(k)
            y+=rows*step
    # Lay out identified redundant uplink groups as coherent blocks before free-node optimization.
    from structure_placement import place_structures
    network_pos,structural_frames,locked,placement_notes=place_structures(nodes,hubs,region,boxes,network_pos,structural_groups or [])
    for n in hubs:nodes[n]['structure_placement_summary']=placement_notes
    # Preserve structural groups while refining remaining nodes.
    from crossing_refinement import optimize
    refinement=optimize(nodes,adj,hubs,region,network_pos,groups_hint=structural_frames+(model_clusters or []),iterations=refine_iterations,locked=locked)
    for n in hubs:nodes[n]['refinement_summary']=refinement
    refreshed=list(structural_frames)
    subboxes=refreshed
    # Put non-network endpoints next to their real parent(s); only degree-1 same-parent,
    # same-category endpoints may intentionally share a slot.
    position=dict(network_pos); occupied=collections.defaultdict(list)
    def cell(x,y):return (int(x//14),int(y//14))
    def radius(n):return 13 if nodes[n].get('is_backbone') else {'core':9,'aggregation':7,'access':4,'other':3,'server':2.4,'ap':2.4}.get(nodes[n]['role'],3)
    def valid(point,r):
        x,y=point;gx,gy=cell(x,y)
        return all((x-u)**2+(y-v)**2 >= (r+rr+0.5)**2 for a in range(gx-2,gx+3) for b in range(gy-2,gy+3) for u,v,rr in occupied[(a,b)])
    def reserve(point,r):occupied[cell(*point)].append((point[0],point[1],r))
    for n,p in network_pos.items():reserve(p,radius(n))
    extras=[n for n in nodes if n not in hubs];multi=sorted((n for n in extras if len(adj[n]-{n})!=1),key=lambda n:(-len(adj[n]),n));single=sorted(set(extras)-set(multi))
    def candidates(center,box):
        x0,y0,x1,y1=box;cx,cy=center
        yield (cx,cy)
        for r in (9,14,20,27,35,46,60,80,110,150,200,280):
            for k in range(32):
                a=2*math.pi*k/32;p=(cx+r*math.cos(a),cy+r*math.sin(a))
                if x0+8<=p[0]<=x1-8 and y0+22<=p[1]<=y1-8:yield p
        y=y0+35
        while y<y1-8:
            x=x0+8
            while x<x1-8:yield (x,y);x+=9
            y+=9
    for n in multi:
        ps=[position[q] for q in adj[n] if q in position];box=boxes[region[n]];cx=sum(p[0] for p in ps)/len(ps) if ps else (box[0]+box[2])/2;cy=sum(p[1] for p in ps)/len(ps) if ps else (box[1]+box[3])/2
        cx=max(box[0]+10,min(box[2]-10,cx));cy=max(box[1]+30,min(box[3]-10,cy))
        for xy in candidates((cx,cy),box):
            if box[0]+5<=xy[0]<=box[2]-5 and box[1]+20<=xy[1]<=box[3]-5 and valid(xy,radius(n)):position[n]=xy;reserve(xy,radius(n));break
        if n not in position:raise ValueError('多邻居或孤立网元没有可用位置：'+n)
    grouped=collections.defaultdict(list)
    for n in single:grouped[next(iter(adj[n]-{n}))].append(n)
    for parent,children in sorted(grouped.items(),key=lambda item:(-len(item[1]),item[0])):
        byrole=collections.defaultdict(list)
        for n in sorted(children):byrole[nodes[n]['role']].append(n)
        maxslots=min(12,len(children));roles=[]
        while len(roles)<maxslots:
            for role in sorted(byrole):
                if roles.count(role)<len(byrole[role]) and len(roles)<maxslots:roles.append(role)
        slots=[];box=boxes[region[parent]];p=position[parent];group_radius=max(radius(n) for n in children)
        for xy in candidates(p,box):
            if box[0]+5<=xy[0]<=box[2]-5 and box[1]+20<=xy[1]<=box[3]-5 and valid(xy,group_radius):slots.append(xy);reserve(xy,group_radius)
            if len(slots)==maxslots:break
        if len(slots)<maxslots:raise ValueError('同父端点空间不足：'+parent)
        for role,group in byrole.items():
            indices=[i for i,v in enumerate(roles) if v==role]
            for i,n in enumerate(group):position[n]=slots[indices[i%len(indices)]]
        clusters.append({'parent':parent,'members':sorted(children),'count':len(children),'visual_slots':maxslots,'region':region[parent],'reused':max(0,len(children)-maxslots)})
    for name,n in nodes.items():
        if name not in position:raise ValueError('网元未布局：'+name)
        n['x'],n['y']=map(lambda v:round(v,2),position[name]);n['region_id']=region[name]
        n.setdefault('is_backbone',False)
    return boxes,clusters,subboxes
