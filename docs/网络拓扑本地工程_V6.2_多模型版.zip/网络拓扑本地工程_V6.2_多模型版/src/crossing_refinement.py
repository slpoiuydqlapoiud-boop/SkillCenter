"""Deterministic graph-based slot swaps. No data-specific node IDs or target coordinates."""
import collections, random
import numpy as np

def optimize(nodes,adj,hubs,regions,positions,groups_hint=None,iterations=2500,locked=None):
    if not 0<=iterations<=20000:raise ValueError('layout_refinement_iterations 需在 0 到 20000 之间')
    names=sorted(hubs);ids={n:i for i,n in enumerate(names)}
    if not names or not iterations:return {'iterations':0,'accepted':0,'reason':'优化关闭或没有网络节点'}
    edges=sorted({tuple(sorted((ids[n],ids[q]))) for n in names for q in adj[n] if q in ids and q!=n})
    if len(edges)>3000:return {'iterations':0,'accepted':0,'reason':'网络边超过 3000，跳过精排；请分区处理'}
    A=np.asarray([e[0] for e in edges],dtype=np.int32);B=np.asarray([e[1] for e in edges],dtype=np.int32)
    coord=np.array([positions[n] for n in names],dtype=float)
    role_radius={'core':9,'aggregation':7,'access':4,'other':3,'server':2.4,'ap':2.4}
    radii=np.array([13 if nodes[n].get('is_backbone') else role_radius[nodes[n]['role']] for n in names],dtype=float)
    bynode=collections.defaultdict(list)
    for k,(a,b) in enumerate(edges):bynode[a].append(k);bynode[b].append(k)
    groups=collections.defaultdict(list);locked=locked or set()
    for n in names:
        depth=nodes[n].get('backbone_distance')
        if depth is not None and not nodes[n].get('is_backbone') and n not in locked:
            groups[(regions[n],min(depth,7))].append(ids[n])
    groups={k:v for k,v in groups.items() if len(v)>=2 and any(bynode[i] for i in v)}
    if not groups or not edges:return {'iterations':0,'accepted':0,'reason':'无可交换节点'}
    rng=random.Random(43157); keys=sorted(groups);weights=[len(groups[k]) for k in keys]
    def intersect(P,Q,R,S):
        a=(Q[:,0]-P[:,0])*(R[:,1]-P[:,1])-(Q[:,1]-P[:,1])*(R[:,0]-P[:,0])
        b=(Q[:,0]-P[:,0])*(S[:,1]-P[:,1])-(Q[:,1]-P[:,1])*(S[:,0]-P[:,0])
        c=(S[:,0]-R[:,0])*(P[:,1]-R[:,1])-(S[:,1]-R[:,1])*(P[:,0]-R[:,0])
        d=(S[:,0]-R[:,0])*(Q[:,1]-R[:,1])-(S[:,1]-R[:,1])*(Q[:,0]-R[:,0])
        return (a*b<0)&(c*d<0)
    # Preserve shared-uplink groups while improving crossings. Nodes can appear in one group per layer.
    group_for={};group_members={}
    for ix,g in enumerate(sorted(groups_hint or [],key=lambda x:x.get('source')!='model')):
        members=[ids[n] for n in g.get('members',[]) if n in ids and ids[n] not in group_for]
        if len(members)<4:continue
        group_members[ix]=members
        for n in members:group_for[n]=ix
    def sse(group):
        a=coord[group_members[group]]
        return float((a*a).sum()-(a.sum(axis=0)**2).sum()/len(a))
    accepted=0;delta_cross=0;attempted=0
    for _ in range(iterations):
        group=groups[rng.choices(keys,weights=weights,k=1)[0]]
        u,v=rng.sample(group,2);affected=np.array(sorted(set(bynode[u])|set(bynode[v])),dtype=np.int32)
        if not len(affected):continue
        ii=np.repeat(affected,len(edges));jj=np.tile(np.arange(len(edges),dtype=np.int32),len(affected))
        # Count each affected/affected edge pair once; skip shared endpoints.
        affected_flag=np.zeros(len(edges),dtype=bool);affected_flag[affected]=True
        mask=(ii!=jj)&(~affected_flag[jj]|(ii<jj))&(A[ii]!=A[jj])&(A[ii]!=B[jj])&(B[ii]!=A[jj])&(B[ii]!=B[jj])
        ii=ii[mask];jj=jj[mask]
        if not len(ii):continue
        old=intersect(coord[A[ii]],coord[B[ii]],coord[A[jj]],coord[B[jj]])
        touched={group_for[x] for x in (u,v) if x in group_for}
        before_compact=sum(sse(g) for g in touched)
        coord[u],coord[v]=coord[v].copy(),coord[u].copy()
        # Swapping positions must remain safe for different visual radii.
        invalid=False
        for node in (u,v):
            diff=coord-coord[node];distance2=(diff*diff).sum(axis=1);limit=(radii+radii[node]+.05)**2
            colliding=distance2<limit;colliding[node]=False
            if np.any(colliding):invalid=True;break
        if invalid:
            coord[u],coord[v]=coord[v].copy(),coord[u].copy();continue
        new=intersect(coord[A[ii]],coord[B[ii]],coord[A[jj]],coord[B[jj]])
        delta=int(new.sum())-int(old.sum());attempted+=1
        compact_delta=(sum(sse(g) for g in touched)-before_compact)/180000.0
        if delta+compact_delta < -1e-9:
            accepted+=1;delta_cross+=delta
        else:coord[u],coord[v]=coord[v].copy(),coord[u].copy()
    for n,i in ids.items():positions[n]=(float(coord[i,0]),float(coord[i,1]))
    return {'iterations':iterations,'evaluated_swaps':attempted,'accepted_swaps':accepted,'crossing_delta':delta_cross,'method':'确定性同区同层换位；联合降低直线近似交叉及共同上联组的离散程度；曲线未计入'}
