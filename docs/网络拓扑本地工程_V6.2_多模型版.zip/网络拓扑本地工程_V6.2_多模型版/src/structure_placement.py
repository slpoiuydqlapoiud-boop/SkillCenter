"""以双上联结构驱动区域内布局；仅使用输入图关系和模型通过校验的决策。"""
import collections,math,copy
from natural_sort import natural_key

def _place_candidate(nodes,hubs,region,boxes,positions,structures):
    selected=[];locked={n for n in hubs if nodes[n].get('is_backbone')};frames=[];notes=[];reflows=[]
    byreg=collections.defaultdict(list)
    for g in structures:
        if all(p in positions for p in g['parents']) and not any(p in locked for p in g['parents']):byreg[g['region']].append(g)
        else:notes.append({'id':g['id'],'reason':'上联父节点缺少位置或已作为全局骨干，保留普通布局'})
    for rid in sorted(boxes):
        x0,y0,x1,y1=boxes[rid];lo=x0+26;hi=x1-26;allg=byreg[rid]
        prim=[];sec=[];occupied_members=set();peers=[g for g in allg if g.get('kind')=='shared_uplink_other_family']
        for g in sorted((g for g in allg if g.get('kind')!='shared_uplink_other_family'),key=lambda z:({'high':0,'normal':1,'low':2}.get(z.get('priority'),1),-z['member_count'],z['id'])):
            if any(n in locked or n in occupied_members for n in g['parents']+g['members']):
                notes.append({'id':g['id'],'reason':'与其他骨干或结构组成员重叠，未启用专用分组位置'});continue
            ds=[nodes[n].get('backbone_distance') for n in g['parents']];ds=[d for d in ds if d is not None];depth=min(ds) if ds else 9
            tier=g.get('preferred_tier','auto');target=prim if (tier=='upper' or (tier=='auto' and depth<=2)) else sec
            limit=max(1,min(8,int((hi-lo)//200)))
            if len(target)>=limit:
                other=sec if target is prim else prim
                if len(other)<limit:
                    target=other;reflows.append({'id':g['id'],'reason':'目标层空间不足，调整至另一可用层'})
                else:
                    notes.append({'id':g['id'],'reason':'两层结构组均超过动态容量'});continue
            z=dict(g);z['parent_depth']=depth;target.append(z);occupied_members.update(z['parents']+z['members'])
        def bands(groups,secondary):
            if not groups:return
            weights=[math.sqrt(max(1,g['member_count']))*g.get('space_weight',1.0) for g in groups];base=min(100,(hi-lo)/len(groups)*.35);available=(hi-lo)-base*len(groups);total=sum(weights);cursor=lo
            for g,w in zip(groups,weights):
                span=base+available*w/total;L=cursor+8;R=cursor+span-8;cursor+=span
                depth=g['parent_depth'];parent_y=1340 if secondary else 590 if depth<=1 else 745
                ystart=parent_y+135
                if secondary:ystart=1450
                max_y=1605 if secondary else (1165 if sec else 1430)
                usable=max(2,int((R-L)//44));kind=g.get('layout_kind','grid');cap=16 if kind=='compact' else 8 if kind=='narrow' else 12;cols=min(cap,max(2,usable),len(g['members']));rows=math.ceil(len(g['members'])/cols)
                if rows>1 and (max_y-ystart)/(rows-1)<21:
                    notes.append({'id':g['id'],'reason':'结构区域过密，退回普通层次布局'});continue
                ystep=47 if rows<=1 else min(52,(max_y-ystart)/(rows-1))
                # Parents are visible above their real common children.
                for i,parent in enumerate(g['parents']):positions[parent]=(L+(i+1)*(R-L)/(len(g['parents'])+1),parent_y);locked.add(parent)
                for i,n in enumerate(sorted(g['members'],key=natural_key)):
                    positions[n]=(L+(i%cols)*(R-L)/max(1,cols-1),ystart+(i//cols)*ystep);locked.add(n)
                bx0=max(x0,L-12);bx1=min(x1,R+12);by0=ystart-24;by1=ystart+(rows-1)*ystep+22
                z={'id':g['id'],'name':g.get('name') or '双上联共同下挂','box':[bx0,by0,bx1,by1],'basis':g['basis'],'region':rid,'parents':g['parents'],'parent':g['parents'][0],'members':list(g['members']),'member_count':len(g['members']),'source':'structural','name_source':g.get('name_source','algorithm'),'model_reason':g.get('model_reason','')}
                frames.append(z);selected.append(g)
        prim.sort(key=lambda g:(g.get('position_x') is None,g.get('position_x') if g.get('position_x') is not None else 0,-g['member_count'],g['id']))
        sec.sort(key=lambda g:(g.get('position_x') is None,g.get('position_x') if g.get('position_x') is not None else 0,-g['member_count'],g['id']))
        bands(prim,False);bands(sec,True)
        for g in peers:
            if any(n in locked for n in g['members']):notes.append({'id':g['id'],'reason':'成员已被其他结构组使用'});continue
            if not all(p in locked for p in g['parents']):notes.append({'id':g['id'],'reason':'共享父组未定位，保留普通布局'});continue
            mid=sum(positions[p][0] for p in g['parents'])/len(g['parents']);py=sum(positions[p][1] for p in g['parents'])/len(g['parents']);count=len(g['members'])
            spacing=min(38,max(18,(hi-lo-30)/max(1,count-1)));left=max(lo,min(hi-spacing*(count-1),mid-spacing*(count-1)/2));yy=max(y0+75,py-65)
            for i,n in enumerate(sorted(g['members'],key=natural_key)):positions[n]=(left+i*spacing,yy);locked.add(n)
            xs=[positions[n][0] for n in g['members']];frame={'id':g['id'],'name':g.get('name') or '共享上联设备组','box':[max(x0,min(xs)-12),yy-18,min(x1,max(xs)+12),yy+18],'basis':g['basis'],'region':rid,'parents':g['parents'],'parent':g['parents'][0],'members':list(g['members']),'member_count':len(g['members']),'source':'structural','name_source':g.get('name_source','algorithm'),'model_reason':g.get('model_reason','')}
            frames.append(frame);selected.append(g)
    # Fix nodes outside structured blocks without suppressing unrelated vertices.
    used=collections.defaultdict(list)
    def cell(x,y):return int(x//24),int(y//24)
    def radius(n):return 10 if nodes[n]['role']=='core' else 8 if nodes[n]['role']=='aggregation' else 5
    def add(n):x,y=positions[n];used[cell(x,y)].append((x,y,radius(n)))
    def free(x,y,r):
        gx,gy=cell(x,y)
        return all((x-a)**2+(y-b)**2>=(r+rr+3)**2 for i in range(gx-1,gx+2) for j in range(gy-1,gy+2) for a,b,rr in used[(i,j)])
    for n in sorted(locked):add(n)
    moves=0
    for n in sorted(hubs-locked,key=lambda v:(nodes[v]['role'] not in ('core','aggregation'),nodes[v].get('backbone_distance') is None,-nodes[v]['data_degree'],v)):
        rid=region[n];x0,y0,x1,y1=boxes[rid];x,y=positions[n];r=radius(n)
        region_frames=[f['box'] for f in frames if f['region']==rid]
        def permissible(xx,yy):return x0+12<=xx<=x1-12 and y0+55<=yy<=y1-12 and not any(a-10<=xx<=c+10 and b-10<=yy<=d+10 for a,b,c,d in region_frames) and free(xx,yy,r)
        if not permissible(x,y):
            found=None
            for rad in (22,40,65,90,130,180,250,350,500,700,1000):
                for i in range(32):
                    angle=2*math.pi*i/32;xx=x+rad*math.cos(angle);yy=y+rad*math.sin(angle)
                    if permissible(xx,yy):found=(xx,yy);break
                if found:break
            if found is None:
                # Exhaustive scan on a local grid; fail visibly instead of hiding devices.
                yy=y0+60
                while yy<=y1-14 and found is None:
                    xx=x0+14
                    while xx<=x1-14:
                        if permissible(xx,yy):found=(xx,yy);break
                        xx+=22
                    yy+=22
            if found is None:raise ValueError('结构分组后无法无碰撞安排网元：'+n)
            positions[n]=found;moves+=1
        add(n)
    return positions,frames,locked,{'structural_groups_placed':len(selected),'ungrouped_network_nodes_repositioned':moves,'groups_not_placed':notes,'reflows':reflows}


def place_structures(nodes,hubs,region,boxes,positions,structures):
    """Try model-relative and graph-depth plans, then choose a feasible solution.

    Coverage and structural priority dominate. Relative preferences are soft;
    fixed absolute tiers from V4 are not directly reused. Every trial works on
    a copy, and only the selected positions are returned.
    """
    candidates=[];attempts=[]
    for strategy in ('model_relative','graph_depth','balance'):
        plan=copy.deepcopy(structures)
        for g in plan:
            hint=g.get('relative_depth','auto')
            if strategy=='model_relative':g['preferred_tier']={'near':'upper','deep':'lower','auto':'auto'}.get(hint,'auto')
            elif strategy=='graph_depth':
                g['preferred_tier']='auto';g['space_weight']=1.0;g['layout_kind']='grid'
            else:
                g['space_weight']=max(.75,min(1.5,g.get('space_weight',1.0)))
                depths=[nodes[p].get('backbone_distance') for p in g['parents'] if p in nodes and nodes[p].get('backbone_distance') is not None]
                depth=min(depths) if depths else 9
                g['preferred_tier']='upper' if depth<=2 or g['member_count']>=30 else 'lower'
        try:
            pos,frames,locked,meta=_place_candidate(nodes,hubs,region,boxes,dict(positions),plan)
        except ValueError as exc:
            attempts.append({'strategy':strategy,'status':'failed','reason':str(exc)});continue
        ids={f['id'] for f in frames};placed=[g for g in plan if g['id'] in ids]
        # Value important / large structures; do not trade them for many tiny boxes.
        utility=sum(100+min(250,g['member_count']*4)+{'high':80,'normal':0,'low':-20}.get(g.get('priority'),0) for g in placed)
        missing=[g['id'] for g in plan if g['id'] not in ids]
        adjusted=sum(1 for g in plan if g.get('relative_depth','auto')!='auto' and strategy!='model_relative')
        # Prefer a graph-consistent vertical location when coverage is equal;
        # this is a proxy, not an exact crossing or readability score.
        depth_penalty=0.0
        for g in placed:
            ds=[nodes[p].get('backbone_distance') for p in g['parents'] if nodes[p].get('backbone_distance') is not None]
            if not ds:continue
            expected=590 if min(ds)<=1 else 745 if min(ds)<=2 else 1340
            depth_penalty+=max(0.0,sum(pos[p][1] for p in g['parents'])/len(g['parents'])-expected)/100*4
        score=utility-adjusted*2-depth_penalty
        attempts.append({'strategy':strategy,'status':'ok','placed':len(placed),'missing':missing,'score':round(score,2),'vertical_depth_penalty':round(depth_penalty,2),'model_depth_hints_adjusted':adjusted})
        candidates.append((score,-len(missing),-len(candidates),pos,frames,locked,meta,strategy))
    if not candidates:raise ValueError('所有局部布局候选都不可行，请查看网络规模和输入质量')
    # Preserve the model's layout preferences whenever they are feasible.
    # A fallback can replace them only if it places strictly more model groups.
    primary=next((c for c in candidates if c[-1]=='model_relative'),None)
    model_by_id={g['id']:g for g in structures}
    def coverage_weight(candidate):
        ids={f['id'] for f in candidate[4]};selected=[model_by_id[i] for i in ids if i in model_by_id]
        return sum(100+min(250,g['member_count']*4)+{'high':80,'normal':0,'low':-20}.get(g.get('priority'),0) for g in selected)
    best=max(candidates,key=lambda c:(coverage_weight(c),c[-2]['structural_groups_placed']))
    chosen=primary if primary is not None and coverage_weight(primary)>=coverage_weight(best) else best
    _,_,_,pos,frames,locked,meta,strategy=chosen
    meta['selected_strategy']=strategy;meta['attempts']=attempts
    meta['selection_reason']='模型方案可行，优先保留模型相对层次和空间建议' if strategy=='model_relative' else '模型方案未能放置部分组，采用能保留更多或更重要模型组的回退方案'

    meta['adjustments']=[{'id':g['id'],'model_relative_depth':g.get('relative_depth','auto'),'model_layout_kind':g.get('layout_kind','grid'),'model_space_weight':g.get('space_weight',1.0),'reason':'采用图距离候选时将相对层次、布局类型及空间权重回退至默认'} for g in structures if strategy=='graph_depth' and (g.get('relative_depth','auto')!='auto' or g.get('layout_kind','grid')!='grid' or g.get('space_weight',1.0)!=1.0)]
    if strategy=='balance':meta['adjustments'] += [{'id':g['id'],'model_relative_depth':g.get('relative_depth','auto'),'model_space_weight':g.get('space_weight',1.0),'reason':'采用平衡候选时根据图深度调整层次，并限制极端空间权重'} for g in structures if g.get('relative_depth','auto')!='auto' or not .75<=g.get('space_weight',1.0)<=1.5]
    return pos,frames,locked,meta
