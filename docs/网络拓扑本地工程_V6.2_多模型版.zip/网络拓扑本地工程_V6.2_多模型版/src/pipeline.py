"""V6: all raw facts are sent in pages; only the model proposes local groups."""
import collections,datetime,hashlib,json,math,os,re,tempfile
from pathlib import Path
from excel_io import read
from graph_layout import analyze,place
from model_api import write
from render_export import svg_and_png,excel
from v6_analysis import pages,run_maps,run_merge,validate_groups

def run(root,cfg,token,prepare_only=False,replay_groups=None,resume_dir=None):
    outbase=root/'output';outbase.mkdir(exist_ok=True)
    out=Path(resume_dir).resolve() if resume_dir else Path(tempfile.mkdtemp(prefix=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_'),dir=outbase))
    if resume_dir and not out.is_dir():raise ValueError('恢复目录不存在：'+str(out))
    from run_lock import locked_run
    with locked_run(out):
        return _run_in_directory(root,cfg,token,prepare_only,replay_groups,out,bool(resume_dir))

def _run_in_directory(root,cfg,token,prepare_only,replay_groups,out,is_resume):
    outbase=root/'output';profile=cfg.get('_profile_id','legacy')
    if not isinstance(profile,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',profile):raise ValueError('无效的模型配置名')
    service_hash=hashlib.sha256(json.dumps([cfg.get('url'),cfg.get('model')],ensure_ascii=False).encode('utf-8')).hexdigest()
    input_hash=hashlib.sha256((root/'input.xlsx').read_bytes()).hexdigest()
    mapping_hash=hashlib.sha256((root/'字段映射.json').read_bytes()).hexdigest()
    ident={'profile':profile,'model':cfg.get('model'),'api_key_env':cfg.get('api_key_env'),'service_fingerprint':service_hash,'input_sha256':input_hash,'mapping_sha256':mapping_hash}
    manifest=out/'模型配置归属.json'
    if is_resume and manifest.exists():
        old=json.loads(manifest.read_text(encoding='utf-8'))
        for k in ('profile','service_fingerprint','api_key_env','input_sha256','mapping_sha256'):
            if old.get(k)!=ident[k]:raise ValueError('不能续跑：该目录的模型配置、接口、输入文件或字段映射已改变；请启动新运行')
    elif is_resume:
        if profile!='legacy':raise ValueError('旧运行目录缺少模型配置归属信息，仅允许使用 legacy 配置续跑')
        prior=out/'输入识别与质量检查.json'
        if prior.exists() and json.loads(prior.read_text(encoding='utf-8')).get('sha256')!=input_hash:raise ValueError('旧运行目录的 Excel 与当前输入不同，请启动新运行')
        print('注意：旧运行目录没有模型配置归属记录，请确认旧运行使用的是当前 legacy 模型。',flush=True)
    write(manifest,ident)
    print('本次输出目录：',out,flush=True)
    print('本次模型配置：',profile,flush=True)
    def pointer(path):
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=outbase,delete=False) as f:
            f.write(str(out)+'\n');tmp=f.name
        os.replace(tmp,path)
    pointer(outbase/f'最新运行目录_{profile}.txt')
    pointer(outbase/'最新运行目录.txt')
    mapping=json.loads((root/'字段映射.json').read_text(encoding='utf-8'))
    print('1/5 解析 Excel 与真实网元/链路事实...',flush=True)
    nodes,edges,summary=read(root/'input.xlsx',mapping);write(out/'输入识别与质量检查.json',summary)
    # These are provisional layout and role hints, not local-group inference.
    adj,pairs,hubs,region=analyze(nodes,edges,int(cfg.get('max_regions',8)))
    hints=[]
    for rid in sorted(set(region.values())):
        members=[n for n in nodes if region[n]==rid]
        hints.append({'id':rid,'node_count':len(members),'name_hint':collections.Counter(nodes[n].get('region_hint','') for n in members).most_common(3),'status':'算法布局占位，非已确认业务区'})
    max_chars=int(cfg.get('max_batch_chars',115000));hint_chars=len(json.dumps(hints,ensure_ascii=False,separators=(',',':')))+200
    chunks=pages(nodes,edges,int(cfg.get('max_edges_per_batch',180)),max_chars-hint_chars)
    # The hints are explicitly provisional; no local group candidates are calculated or passed.
    for c in chunks:
        c['layout_region_hints']=hints
        if len(json.dumps(c,ensure_ascii=False,separators=(',',':')))>max_chars:raise ValueError('事实页超过 max_batch_chars，请调整分页设置')
    facts=out/'模型事实页';facts.mkdir(exist_ok=True)
    for c in chunks:write(facts/(c['page_id']+'.json'),c)
    all_sent_nodes={n['name'] for c in chunks for n in c['nodes']};all_sent_edges=[e['id'] for c in chunks for e in c['edges']];edge_lookup={e['id']:e for c in chunks for e in c['edges']}
    coverage={'input_nodes':len(nodes),'input_valid_edge_rows':len(edges),'fact_pages':len(chunks),'unique_nodes_in_pages':len(all_sent_nodes),'edge_records_in_pages':len(all_sent_edges),'unique_edge_ids_in_pages':len(set(all_sent_edges)),'all_nodes_paged':all_sent_nodes==set(nodes),'all_valid_edge_rows_paged_once':len(all_sent_edges)==len(edges)==len(set(all_sent_edges)),'note':'分页包含两张已识别工作表的非空字段；已发送或模型声称检查不等于理解正确'}
    write(out/'事实分页覆盖.json',coverage)
    if not coverage['all_nodes_paged'] or not coverage['all_valid_edge_rows_paged_once']:raise RuntimeError('事实分页覆盖失败，已停止')
    if prepare_only:
        print('已生成事实页；未调用模型，也未推断局部组。',flush=True);return out
    replay=replay_groups is not None;mock=bool(cfg.get('mock_simulation')) and not replay
    map_errors=[];merge_stats={'calls':[],'cross_page_merge_not_evaluated':False};region_plans=[];backbones=[];assessments=[];region_suggestions=[];partial_error=None
    if replay:
        raw=json.loads(Path(replay_groups).read_text(encoding='utf-8-sig'))
        if not isinstance(raw,dict) or raw.get('input_sha256')!=summary['sha256'] or not isinstance(raw.get('groups'),list):raise ValueError('历史子组包无效或输入哈希不匹配')
        proposals=[]
        for i,g in enumerate(raw['groups'],1):
            if isinstance(g,dict):
                g=dict(g);g.update(id=f'H{i:06d}',source_page='historical_replay');g.setdefault('parents',[]);proposals.append(g)
        coverage.update(model_called=False,mode='historical_replay',model_reported_reviewed_nodes=None,model_reported_reviewed_edges=None)
        print('2/5 回放历史模型子组；本次未调用模型，不能宣称全量模型推理...',flush=True)
    else:
        print(f'2/5 模型逐页推断：共 {len(chunks)} 个事实页；至少 {len(chunks)+1} 次接口调用，归并/重试可能增加调用次数和费用。',flush=True)
        proposals,results,map_errors,backs,region_suggestions,assessments,partial_error=run_maps(cfg,token,chunks,out)
        reported_unique=set()
        for chunk,result in zip(chunks,results):reported_unique.update({n['name'] for n in chunk['nodes']}-set(result['missing_nodes']))
        coverage.update(model_called=not mock,mode='mock' if mock else 'api',completed_fact_pages=len(results),all_fact_pages_completed=len(results)==len(chunks),model_reported_reviewed_nodes=sum(x['nodes_model_reported_reviewed'] for x in results),model_reported_reviewed_edges=sum(x['edges_model_reported_reviewed'] for x in results),model_reported_reviewed_unique_nodes=len(reported_unique),model_reported_reviewed_note='节点跨页重复；这些仅是模型自报已检查，非正确率证明')
        coverage['model_self_report_complete']=all(not x['missing_nodes'] and not x['missing_edges'] for x in results) and len(results)==len(chunks)
        write(out/'模型事实页提议.json',proposals)
        proposals,pre_rejected=validate_groups(proposals,nodes,adj,region,edge_lookup);map_errors.extend(pre_rejected)
        write(out/'模型事实页校验后.json',proposals)
        print('3/5 模型比较、归并其自主提出的局部组...',flush=True)
        if not partial_error:
            try:
                proposals,merge_stats,region_plans,backbones=run_merge(cfg,token,proposals,hints,backs,region_suggestions,out,adj,{n['name']:n for c in chunks for n in c['nodes']},[e for c in chunks for e in c['edges']])
            except (ValueError,RuntimeError,OSError,KeyError) as exc:
                partial_error={'stage':'模型归并','error_type':type(exc).__name__,'message':str(exc)}
                write(out/'模型中断诊断.json',partial_error)
                merge_stats={'calls':[],'cross_page_merge_not_evaluated':True,'error':partial_error,'rejected':[]}
                print('模型归并未完成，保留已验证模型组并导出未完成预览：'+str(exc),flush=True)
        else:merge_stats={'calls':[],'cross_page_merge_not_evaluated':True,'error':partial_error,'rejected':[]}
        if not backbones:backbones=backs;merge_stats['backbone_fallback']='归并未指定骨干，保留事实页模型建议'
    write(out/'模型覆盖报告.json',coverage);write(out/'模型归并报告.json',merge_stats)
    write(out/'模型节点与区域原始建议.json',{'node_assessments':assessments,'region_suggestions':region_suggestions,'merge_region_names':region_plans,'merge_backbones':backbones})
    # Apply only unambiguous model node suggestions; unresolved cases remain explicit layout hints.
    votes=collections.defaultdict(lambda:{'role':set(),'region':set()})
    for a in assessments:
        n=a.get('name');role=a.get('role');rr=a.get('region_id')
        if n not in nodes:continue
        if role in ('core','aggregation','access','other'):votes[n]['role'].add(role)
        if isinstance(rr,str) and rr in set(region.values()):votes[n]['region'].add(rr)
    applied=[];conflicts=[]
    for n,v in votes.items():
        if len(v['role'])>1 or len(v['region'])>1:conflicts.append({'name':n,'role':sorted(v['role']),'region':sorted(v['region'])});continue
        if v['role']:nodes[n]['role']=next(iter(v['role']));nodes[n]['role_basis']='模型建议，待专家确认';applied.append({'name':n,'role':nodes[n]['role']})
        if v['region']:region[n]=next(iter(v['region']));applied.append({'name':n,'region':region[n]})
    for n in nodes:
        if nodes[n]['role'] in ('core','aggregation','access'):nodes[n]['network_device']=True;hubs.add(n)
    # Actual region proposals originate from the model. Identical labels are
    # treated as the same label, not as an inferred semantic merge.
    named_votes=collections.defaultdict(set);region_positions=collections.defaultdict(set)
    for r in region_suggestions:
        label=r['name'].strip()[:40]
        for n in r['members']:named_votes[n].add(label)
        x=r.get('position_x')
        if isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and 0<=x<=1:region_positions[label].add(float(x))
    labels=sorted({name for names in named_votes.values() for name in names});max_model_regions=int(cfg.get('max_model_regions',16))
    if not 1<=max_model_regions<=64:raise ValueError('max_model_regions 范围为1至64')
    model_region_names={};model_region_conflicts=[]
    if len(labels)>max_model_regions:
        model_region_conflicts.append({'reason':'模型自提区域超过可视上限，暂不应用；原始建议完整保留','count':len(labels),'limit':max_model_regions})
    else:
        label_ids={label:f'MR{i:03d}' for i,label in enumerate(labels,1)}
        for n,names in named_votes.items():
            if len(names)==1:
                label=next(iter(names));region[n]=label_ids[label];applied.append({'name':n,'model_region':label})
            else:model_region_conflicts.append({'name':n,'model_regions':sorted(names),'reason':'模型区域建议冲突，保留原布局占位'})
        for label,rid in label_ids.items():
            if rid in set(region.values()):model_region_names[rid]=label
    info={rid:{'id':rid,'name':model_region_names.get(rid,rid+' 待确认区域'),'anchor':None,'basis':'模型区域建议，待专家确认' if rid in model_region_names else '程序初始布局占位，非业务区结论','source':'model' if rid in model_region_names else 'layout_hint'} for rid in sorted(set(region.values()))}
    for rid,label in model_region_names.items():
        if len(region_positions[label])==1:info[rid]['anchor']=[next(iter(region_positions[label])),.5]
        elif len(region_positions[label])>1:model_region_conflicts.append({'region':label,'reason':'模型对区域横向顺序不一致，未自动应用'})
    region_choices=collections.defaultdict(set)
    for v in region_plans:
        if not isinstance(v,dict):continue
        rid=v.get('id');name=v.get('name');x=v.get('anchor_x')
        if rid in info and isinstance(name,str) and name.strip() and isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and 0<=x<=1:
            region_choices[rid].add((name.strip()[:40],float(x)))
    region_plan_conflicts=[]
    for rid,choices in region_choices.items():
        if len(choices)==1:
            name,x=next(iter(choices));info[rid].update(name=name,anchor=[x,.5],basis='模型给出的区域名称和横向顺序，需专家确认',source='model')
        else:region_plan_conflicts.append({'region':rid,'suggestions':sorted(choices),'reason':'多次模型归并对大区意见冲突，暂用待确认布局占位'})
    for n in backbones:
        if isinstance(n,str) and n in hubs and (adj[n]-{n}):
            selected=info[region[n]].setdefault('model_backbone_nodes',[])
            if n not in selected and len(selected)<4:selected.append(n)
    groups,rejected=validate_groups(proposals,nodes,adj,region,edge_lookup);rejected=map_errors+merge_stats.get('rejected',[])+rejected
    write(out/'模型自主组_校验后.json',groups);write(out/'模型组校验与拒绝.json',{'rejected':rejected,'node_assessments_applied':applied,'conflicts':conflicts,'model_region_conflicts':model_region_conflicts,'region_plan_conflicts':region_plan_conflicts,'unassessed_nodes':len(set(nodes)-set(votes)),'nodes_with_model_region_suggestions':len(named_votes),'note':'模型未明确建议的角色/大区保留初始布局提示，不作为已确认结论'})
    # Translate the model's own group for local grid placement where parents and
    # same-region network members allow it. No model group is generated here.
    structural=[];mapping_notes=[]
    for g in groups:
        ps=[n for n in g['parents'] if n in hubs];ms=[n for n in g['members'] if n in hubs and n not in ps]
        if ps and len(ms)>=2 and len(set(region[n] for n in ps+ms))==1 and all(any(p in adj[n] for p in ps) for n in ms):
            tier=g.get('relative_depth','auto');tier=tier if tier in ('auto','near','deep') else 'auto'
            priority=g.get('priority','normal');priority=priority if priority in ('high','normal','low') else 'normal'
            kind=g.get('layout_kind','grid');kind=kind if kind in ('grid','compact','narrow') else 'grid'
            weight=g.get('space_weight',1);weight=weight if isinstance(weight,(int,float)) and not isinstance(weight,bool) and math.isfinite(weight) and .5<=weight<=2 else 1
            x=g.get('position_x');x=x if isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and 0<=x<=1 else None
            structural.append({'id':g['id'],'region':region[ps[0]],'kind':'model_proposal','parents':ps,'members':ms,'member_count':len(ms),'basis':str(g.get('reason',''))[:500],'name':g['name'],'name_source':'model','model_reason':str(g.get('reason',''))[:300],'relative_depth':tier,'priority':priority,'layout_kind':kind,'space_weight':weight,'position_x':x})
        else:mapping_notes.append({'id':g['id'],'reason':'无明确父节点、成员太少、跨占位区或未逐一连接父节点；仍保留模型组并绘制边界'})
    print('4/5 本地根据模型组和真实连线计算坐标...',flush=True)
    boxes,clusters,_=place(nodes,adj,hubs,region,info,refine_iterations=int(cfg.get('layout_refinement_iterations',2500)),structural_groups=structural,model_clusters=[{'members':g['all_members'],'source':'model'} for g in groups])
    from layout_checks import audit
    collision=audit(nodes,clusters);write(out/'节点碰撞校验.json',collision)
    if collision['unrelated_overlap_pairs']:print('警告：存在不同父节点碰撞，结果将标记待检查；详见 节点碰撞校验.json',flush=True)
    # Bounds are built from actual model group members, including backbone nodes.
    # They are clamped to the canvas, not to the internal region rectangle.
    frames=[]
    for g in groups:
        xy=[(nodes[n]['x'],nodes[n]['y']) for n in g['all_members']];xs=[a for a,b in xy];ys=[b for a,b in xy]
        box=[max(5,min(xs)-18),max(120,min(ys)-22),min(3195,max(xs)+18),min(1750,max(ys)+22)]
        if box[2]<=box[0] or box[3]<=box[1]:raise ValueError('模型子组边界无效：'+g['id'])
        frames.append({'id':g['id'],'name':g['name'],'box':box,'basis':str(g.get('reason','')),'region':g['region_hint'],'parents':g['parents'],'members':g['all_members'],'member_count':len(g['all_members']),'source':'model','name_source':'model','uncertain':g['verification']['needs_expert_review']})
    print('5/5 导出整体图、坐标和模型证据...',flush=True)
    visual_mode='incomplete' if partial_error else 'replay' if replay else 'mock' if mock else 'unverified' if not coverage.get('model_self_report_complete') or any(c.get('model_missing_proposal_ids') for c in merge_stats.get('calls',[])) else True
    if collision['unrelated_overlap_pairs']:visual_mode='collision' if not partial_error else 'incomplete'
    shown=svg_and_png(nodes,pairs,boxes,info,clusters,frames,out,visual_mode)
    excel(nodes,edges,info,boxes,clusters,out)
    payload={'version':'generic-6-model-discovery','input':summary,'model_mode':coverage['mode'],'nodes':list(nodes.values()),'edges':edges,'regions':list(info.values()),'boxes':boxes,'clusters':clusters,'model_groups':groups,'displayed_subregions':shown,'rejected_model_proposals':rejected}
    write(out/'渲染数据与布局结果.json',payload)
    placement=next((n.get('structure_placement_summary') for n in nodes.values() if n.get('structure_placement_summary')),None)
    report={'input_sha256':summary['sha256'],'model_mode':coverage['mode'],'model_run_incomplete':bool(partial_error),'model_failure':partial_error,'visual_status':visual_mode,'node_names':len(nodes),'valid_link_rows':len(edges),'device_pairs':len(pairs),'input_facts_coverage':coverage,'model_proposal_count':len(proposals),'validated_model_groups':len(groups),'groups_needing_expert_review':sum(g['verification']['needs_expert_review'] for g in groups),'rejected_model_proposals':len(rejected),'displayed_model_group_frames':len(shown),'structural_layout_candidates':len(structural),'structural_layout_groups_placed':placement.get('structural_groups_placed',0) if placement else 0,'group_mapping_notes':mapping_notes,'placement':placement,'collision':collision,'merge':merge_stats,'warnings':['局部组由模型提出，连接校验不能保证语义正确','分页与模型自报已检查不证明找全所有结构','未被模型明确分类的角色与大区为布局提示，需专家确认','跨归并页的局部组不保证被比较' if merge_stats.get('cross_page_merge_not_evaluated') else '模型可能漏判跨事实页结构','同父同角色单邻居可叠放，静态图不可逐一辨认']}
    if not groups:report['warnings'].append('模型未提出任何可保留的局部组；请核查模型回复与事实页，不能据此断定网络没有局部结构')
    write(out/'处理校验报告.json',report)
    if not partial_error and (out/'模型中断诊断.json').exists():(out/'模型中断诊断.json').unlink()
    write(out/'处理流程.json',{'stages':[{'stage':'Excel解析与事实分页','executor':'本地Python','result':'不产生局部组'},{'stage':'逐事实页识别局部组','executor':'历史回放' if replay else '模拟HTTP' if mock else '配置的大模型','result':'模型自行提出组，不提供程序预算组'},{'stage':'模型比较与归并','executor':'跳过，历史回放' if replay else '模拟HTTP' if mock else '配置的大模型'},{'stage':'核对节点、链路、分组证据','executor':'本地Python'},{'stage':'组约束布局与渲染','executor':'本地Python'}]})
    if partial_error:print('注意：只生成未完成预览，模型没有完成全量处理；请查看 模型中断诊断.json 后恢复运行。',flush=True)
    print(f"导出：{len(nodes)} 个名称身份，{len(edges)} 条有效链路，{len(groups)} 个有效名称模型组；其中 {sum(g['verification']['needs_expert_review'] for g in groups)} 组连接证据不足需核实。",flush=True)
    print('图片文件：',out/'整体网络拓扑.svg',flush=True)
    print('图片文件：',out/'整体网络拓扑_4K.png',flush=True)
    if not groups:print('注意：模型没有给出可保留的局部组；不能据此认为网络没有局部结构。',flush=True)
    if rejected:print('注意：部分模型建议被拒绝，请查看 模型组校验与拒绝.json。',flush=True)
    return out
