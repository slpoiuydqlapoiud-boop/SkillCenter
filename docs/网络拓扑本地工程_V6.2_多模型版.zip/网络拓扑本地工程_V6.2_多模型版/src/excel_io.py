import collections, hashlib, ipaddress, re
from pathlib import Path
from openpyxl import load_workbook

ALIASES={
'name':['网元名称','设备名称','节点名称','网元名','设备名','节点名','nodename','devicename','name','hostname'],
'ip':['网元ip','设备ip','管理ip','管理地址','网管ip','managementip','ipaddress','ip'],
'role':['网元角色','设备角色','网络角色','节点角色','网络层次','设备层级','role','noderole','layer'],
'region':['所属区域','业务区域','所属园区','所属站点','所属机房','区域','region','site','zone'],
'device_type':['设备类型','网元类型','设备型号','device_type','devicetype','型号'],
'a':['源网元名称','源设备名称','a端网元名称','a端设备名称','a端网元','a端设备','源网元','源设备','源节点','源节点名称','起点网元','source','source_name','sourcenode','nodea','a'],
'b':['宿网元名称','宿设备名称','目的网元名称','目的设备名称','目标网元名称','目标设备名称','z端网元名称','z端设备名称','b端网元名称','b端设备名称','z端网元','z端设备','b端网元','b端设备','目的网元','目的设备','目标节点','宿网元','宿设备','target','target_name','destination','dest','nodeb','b'],
'a_port':['源端口名称','源端口','a端端口','a端端口名称','sourceport','aport'],
'b_port':['宿端口名称','目的端口名称','目标端口名称','宿端口','目的端口','z端端口','b端端口','targetport','destinationport','bport'],
'bandwidth':['链路带宽（m）','链路带宽','带宽','速率','bandwidth','speed'],
'type':['链路类型（通常填物理链路）','链路类型','连接类型','linktype','type']}

def norm(v):return re.sub(r'[\s_\-（）()：:./]+','',str(v or '').strip().lower())
ALIAS={k:{norm(x) for x in vals} for k,vals in ALIASES.items()}
def text(v):return '' if v is None else str(v).strip()
def empty(v):return not v or v in ('-','--','无','未知','N/A','n/a','NULL','null')

def resolve(headers, field, forced):
    if forced:
        matches=[i for i,h in enumerate(headers) if text(h)==forced]
        if len(matches)!=1:raise ValueError(f'字段映射 {field} 指定的表头 {forced!r} 不存在或重复')
        return matches[0]
    matches=[i for i,h in enumerate(headers) if norm(h) in ALIAS[field] and norm(h)]
    if len(matches)>1:
        # Prefer aliases earlier in the user's contract rather than arbitrary sheet order.
        ranked=sorted(matches,key=lambda i:next(j for j,a in enumerate(ALIASES[field]) if norm(a)==norm(headers[i])))
        if norm(headers[ranked[0]])==norm(headers[ranked[1]]):raise ValueError(f'字段 {field} 存在重复表头，请在字段映射.json指定')
        return ranked[0]
    return matches[0] if matches else None

def detect(wb, kind, config):
    opts=config.get(kind,{}) or {};required=['name'] if kind=='网元表' else ['a','b'];keys=['name','ip','role','region','device_type'] if kind=='网元表' else ['a','b','a_port','b_port','type','bandwidth']
    sname=opts.get('sheet') or '';rownum=int(opts.get('header_row') or 0);forced=opts.get('columns') or {}
    if sname and sname not in wb.sheetnames:raise ValueError(f'{kind} 指定的工作表不存在：{sname}')
    results=[]
    for sh in wb.worksheets:
        if sname and sh.title!=sname:continue
        for row in sh.iter_rows(min_row=rownum or 1,max_row=rownum or min(sh.max_row,10),values_only=False):
            hs=[c.value for c in row]
            # Before resolving non-required fields, avoid treating unrelated sheets as candidates.
            try:
                mapped={k:resolve(hs,k,forced.get(k,'')) for k in keys}
            except ValueError:
                if sname and rownum:raise
                continue
            if all(mapped[k] is not None for k in required):
                if kind=='网元表' and not sname and resolve(hs,'a','') is not None and resolve(hs,'b','') is not None:continue
                if len(set(mapped[k] for k in required))!=len(required):continue
                score=sum(v is not None for v in mapped.values())
                results.append((score,sh,row[0].row,mapped,hs))
    if not results:
        if kind=='网元表' and not sname:return None
        raise ValueError(f'未识别 {kind} 的必要表头，请在 字段映射.json 中指定 sheet、header_row、columns')
    results.sort(key=lambda x:(-x[0],x[1].title,x[2]))
    if len(results)>1 and results[0][0]==results[1][0] and not (sname and rownum):raise ValueError(f'{kind} 有多个匹配表头，请在 字段映射.json 指定 sheet 和 header_row')
    _,sh,hrow,mapped,hs=results[0]
    return sh,hrow,mapped,hs

def read(path, mapping):
    path=Path(path)
    if not path.is_file():raise ValueError('找不到 input.xlsx，请放在工程根目录')
    if path.suffix.lower()!='.xlsx':raise ValueError('仅支持 .xlsx，请先将 .xls 或 csv 另存为 .xlsx')
    wb=load_workbook(path,read_only=True,data_only=True)
    try:
        inventory=detect(wb,'网元表',mapping);links=detect(wb,'链路表',mapping)
        if inventory and inventory[0].title==links[0].title and inventory[1]==links[1]:raise ValueError('网元表和链路表不能指向同一表头')
        nodes={};edges=[];skipped=[];duplicates=[];invalid_ips=[]
        def value(row,fields,k):
            i=fields.get(k);return text(row[i]) if i is not None and i<len(row) else ''
        if inventory:
            sh,h,fields,headers=inventory
            for rn,row in enumerate(sh.iter_rows(min_row=h+1,values_only=True),h+1):
                name=value(row,fields,'name')
                if empty(name):
                    if any(not empty(text(x)) for x in row):skipped.append({'sheet':sh.title,'row':rn,'reason':'网元名称为空'})
                    continue
                ip_raw=value(row,fields,'ip');ip=''
                if not empty(ip_raw):
                    try:ipaddress.ip_address(ip_raw);ip=ip_raw
                    except ValueError:invalid_ips.append({'sheet':sh.title,'row':rn,'name':name,'original_value':ip_raw})
                rec={'name':name,'known':True,'inventory_rows':[rn],'ip':ip,'ip_raw':ip_raw,'raw_role':value(row,fields,'role'),'raw_region':value(row,fields,'region'),'device_type':value(row,fields,'device_type'),'source_attributes':{str(i+1)+':'+text(headers[i]):text(v) for i,v in enumerate(row) if i<len(headers) and v is not None and text(v)}}
                rec['source_inventory_records']=[{'row':rn,'attributes':dict(rec['source_attributes'])}]
                if name in nodes:
                    nodes[name]['source_inventory_records'].extend(rec['source_inventory_records'])
                    nodes[name]['inventory_rows'].append(rn);duplicates.append({'name':name,'rows':list(nodes[name]['inventory_rows']),'reason':'名称重复；按名称暂合并，需确认是否为不同设备'})
                else:nodes[name]=rec
        sh,h,fields,headers=links
        for rn,row in enumerate(sh.iter_rows(min_row=h+1,values_only=True),h+1):
            a=value(row,fields,'a');b=value(row,fields,'b')
            if empty(a) or empty(b):
                if any(not empty(text(x)) for x in row):skipped.append({'sheet':sh.title,'row':rn,'reason':'链路端点缺失','a':a,'b':b})
                continue
            for n in (a,b):
                if n not in nodes:nodes[n]={'name':n,'known':False,'inventory_rows':[],'ip':'','raw_role':'','raw_region':'','device_type':''}
            edges.append({'a':a,'b':b,'a_port':value(row,fields,'a_port'),'b_port':value(row,fields,'b_port'),'type':value(row,fields,'type'),'bandwidth':value(row,fields,'bandwidth'),'row':rn,'sheet':sh.title,'source_attributes':{str(i+1)+':'+text(headers[i]):text(v) for i,v in enumerate(row) if i<len(headers) and v is not None and text(v)}})
        if not nodes:raise ValueError('未找到任何有效网元')
        summary={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'inventory_sheet':inventory[0].title if inventory else None,'inventory_header_row':inventory[1] if inventory else None,'link_sheet':links[0].title,'link_header_row':links[1], 'inventory_mapping':{k:inventory[3][v] for k,v in inventory[2].items() if v is not None} if inventory else {},'link_mapping':{k:links[3][v] for k,v in links[2].items() if v is not None},'node_count':len(nodes),'inventory_node_count':sum(n['known'] for n in nodes.values()),'link_only_node_count':sum(not n['known'] for n in nodes.values()),'valid_link_rows':len(edges),'skipped_rows':skipped,'duplicate_names':duplicates,'invalid_inventory_ips':invalid_ips}
        return nodes,edges,summary
    finally:wb.close()
