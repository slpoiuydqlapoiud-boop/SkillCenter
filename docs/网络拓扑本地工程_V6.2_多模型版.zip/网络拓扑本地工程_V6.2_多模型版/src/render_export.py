import collections, functools, html, json, math, os, re, tempfile, xml.etree.ElementTree as ET
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter

COLORS={'core':'#db4d5f','aggregation':'#e5a11d','access':'#338fc9','other':'#8695a6','server':'#9c58b5','ap':'#169f8a'}
NS='http://www.w3.org/2000/svg';ET.register_namespace('',NS);T=lambda t:'{'+NS+'}'+t
FONT=Path(__file__).with_name('cjk.ttf')
def svg_and_png(nodes,pairs,boxes,regions,clusters,subboxes,out,model_used):
    W,H=3200,1800;root=ET.Element(T('svg'),{'width':str(W),'height':str(H),'viewBox':f'0 0 {W} {H}'})
    ET.SubElement(root,T('rect'),{'width':str(W),'height':str(H),'fill':'#ffffff'})
    image=Image.new('RGB',(3840,2160),'white');draw=ImageDraw.Draw(image);scale=1.2
    @functools.lru_cache(maxsize=32)
    def font(size):return ImageFont.truetype(str(FONT),max(1,round(size*scale)))
    def px(x):return round(x*scale)
    def text(x,y,s,size=18,color='#233950'):
        e=ET.SubElement(root,T('text'),{'x':str(round(x,1)),'y':str(round(y,1)),'font-size':str(size),'fill':color,'font-family':'Microsoft YaHei, Noto Sans CJK SC, sans-serif'});e.text=str(s)
        draw.text((px(x),px(y-size)),str(s),font=font(size),fill=color)
    def mix(col,alpha):
        c=tuple(int(col[i:i+2],16) for i in (1,3,5));return tuple(round(255+(x-255)*alpha) for x in c)
    def polyline(points,col,width=1,alpha=.6,dash=None,path=None):
        if path:ET.SubElement(root,T('path'),{'d':path,'fill':'none','stroke':col,'stroke-width':str(width),'stroke-opacity':str(alpha),**({'stroke-dasharray':'5 6'} if dash else {})})
        else:ET.SubElement(root,T('line'),{'x1':str(points[0][0]),'y1':str(points[0][1]),'x2':str(points[-1][0]),'y2':str(points[-1][1]),'stroke':col,'stroke-width':str(width),'stroke-opacity':str(alpha),**({'stroke-dasharray':'5 6'} if dash else {})})
        draw.line([(px(x),px(y)) for x,y in points],fill=mix(col,alpha),width=max(1,px(width)))
    text(48,62,'整体网络拓扑 · 全量网元',38)
    status={'mock':'本机模拟接口（未调用真实模型）','replay':'历史模型子组回放（未调用模型）','incomplete':'模型推理未完成 · 此图仅为预览','unverified':'模型已返回但未逐项自报覆盖 · 请核查','collision':'布局存在节点碰撞 · 请核查'}.get(model_used,'模型参与规划' if model_used else '离线算法模式')
    text(48,105,f"{len(nodes)} 个名称身份 / {len(pairs)} 对设备关系 · {status}",19,'#b34b24' if model_used in ('incomplete','unverified','collision') else '#536b83')
    for i,(role,label) in enumerate([('core','核心'),('aggregation','汇聚'),('access','接入'),('server','服务器'),('ap','AP'),('other','未知')]):
        x=1280+i*285;ET.SubElement(root,T('circle'),{'cx':str(x),'cy':'58','r':'7','fill':COLORS[role]});draw.ellipse((px(x-7),px(51),px(x+7),px(65)),fill=COLORS[role]);text(x+16,65,label,18,'#536b83')
    for rid,box in boxes.items():
        x0,y0,x1,y1=box;points=[(x0,y0+25),(x0+35,y0),(x1-35,y0),(x1,y0+25),(x1,y1-25),(x1-30,y1),(x0+30,y1),(x0,y1-25)]
        ET.SubElement(root,T('polygon'),{'points':' '.join(f'{x:.1f},{y:.1f}' for x,y in points),'fill':'#f4f7fb'});draw.polygon([(px(x),px(y)) for x,y in points],fill='#f4f7fb');text(x0+18,y0+55,regions[rid]['name'][:24],22,'#637a94')
    # The model decides grouping; retain each validated group box.
    shown=list(subboxes)
    for z in shown:
        x0,y0,x1,y1=z['box'];stroke='#c38b35' if z.get('uncertain') else '#9cb2c8';ET.SubElement(root,T('rect'),{'x':str(x0),'y':str(y0),'width':str(x1-x0),'height':str(y1-y0),'rx':'6','fill':'none','stroke':stroke,'stroke-width':'1.4','stroke-dasharray':'7 6'})
        for x in range(px(x0),px(x1),12):draw.line((x,px(y0),min(x+7,px(x1)),px(y0)),fill=stroke);draw.line((x,px(y1),min(x+7,px(x1)),px(y1)),fill=stroke)
        for y in range(px(y0),px(y1),12):draw.line((px(x0),y,px(x0),min(y+7,px(y1))),fill=stroke);draw.line((px(x1),y,px(x1),min(y+7,px(y1))),fill=stroke)
        parent_names=[]
        for name in z.get('parents',[])[:2]:
            label=name
            if label.startswith('NE-'):label=label[3:]
            hint=nodes[name].get('region_hint','')
            if hint and label.startswith(hint+'-'):label=label[len(hint)+1:]
            parent_names.append(label[:18])
        label=z['name'] if z.get('source')=='model' or z.get('name_source')=='model' else '/'.join(parent_names)+' 下挂' if parent_names else ''
        if x1-x0>80 and y1-y0>25 and label:text(x0+5,y0+14,label[:30],10,'#7187a0')
    from graph_layout import is_management
    def priority(item):
        (a,b),_=item;cross=nodes[a]['region_id']!=nodes[b]['region_id'];back=cross and nodes[a].get('is_backbone') and nodes[b].get('is_backbone');return (back, nodes[a]['role'] in ('core','aggregation') and nodes[b]['role'] in ('core','aggregation'))
    for (a,b),records in sorted(pairs.items(),key=priority):
        n,m=nodes[a],nodes[b];x,y=n['x'],n['y'];u,v=m['x'],m['y'];cross=n['region_id']!=m['region_id'];back=cross and n.get('is_backbone') and m.get('is_backbone');management=all(is_management(e) for e in records)
        if a==b:
            ET.SubElement(root,T('circle'),{'cx':str(x+5),'cy':str(y-5),'r':'6','fill':'none','stroke':'#adbacc','stroke-width':'1'});draw.ellipse((px(x-1),px(y-11),px(x+11),px(y+1)),outline='#adbacc',width=1);continue
        if back:
            h=max(100,265-abs(u-x)*.08);cx=(x+u)/2;path=f'M{x},{y} Q{cx},{h} {u},{v}'
            points=[((1-t)**2*x+2*t*(1-t)*cx+t*t*u,(1-t)**2*y+2*t*(1-t)*h+t*t*v) for t in [i/40 for i in range(41)]]
            polyline(points,'#355679',2.8,.88,path=path)
        else:
            important=n['role'] in ('core','aggregation') and m['role'] in ('core','aggregation')
            alpha=.12 if management else .55 if important else .28 if n.get('network_device') and m.get('network_device') else .13
            polyline([(x,y),(u,v)],'#6683a1',1.4 if important else .8,alpha,dash=management)
    # Label key devices and as many individual network devices as fit, while keeping full names in SVG/Excel.
    labels={};label_boxes=[]
    ordered=sorted(nodes,key=lambda n:(not nodes[n].get('is_backbone'),nodes[n]['role'] not in ('core','aggregation'),not nodes[n].get('network_device'),-nodes[n]['data_degree'],n))
    def short_name(name,n):
        label=name[3:] if name.startswith('NE-') else name
        hint=n.get('region_hint','')
        if not n.get('is_backbone') and hint and label.startswith(hint+'-'):label=label[len(hint)+1:]
        m=re.fullmatch(r'(?i)(acc|leaf)[-_](sw|rt)(\d+)',label)
        if m:return ('L' if m.group(1).lower()=='leaf' else 'R' if m.group(2).lower()=='rt' else 'A')+m.group(3)
        if len(label)>32:return label[:29]+'…'
        return label
    for name in ordered:
        n=nodes[name];rid=n['region_id'];isroot=n.get('is_backbone');important=n['role'] in ('core','aggregation')
        if not n.get('network_device') and not isroot:continue
        label=short_name(name,n);size=20 if isroot else 14 if important else 10
        if not important and len(label)>16:label=label[:13]+'…'
        tw=font(size).getlength(label)/scale;x=n['x'];y=n['y'];r=13 if isroot else 9 if important else 4
        candidates=[(x-tw/2,y+r+size+2),(x-tw/2,y-r-4),(x+r+3,y+size/3),(x-r-tw-3,y+size/3)]
        for lx,ly in candidates:
            lb=(lx,ly-size,lx+tw,ly+3)
            if lb[0]<12 or lb[2]>3188 or lb[1]<130 or lb[3]>1750:continue
            if any(not (lb[2]+2<b[0] or lb[0]>b[2]+2 or lb[3]+2<b[1] or lb[1]>b[3]+2) for b in label_boxes):continue
            if any(other!=name and lb[0]-2<v['x']<lb[2]+2 and lb[1]-2<v['y']<lb[3]+2 for other,v in nodes.items() if v.get('network_device')):continue
            label_boxes.append(lb);labels[name]=(lx,ly,label,size);break
    for name,n in nodes.items():
        x,y=n['x'],n['y'];r=13 if n.get('is_backbone') else {'core':9,'aggregation':7,'access':4,'other':3,'server':2.4,'ap':2.4}[n['role']];col=COLORS[n['role']]
        g=ET.SubElement(root,T('g'),{'class':'node','data-name':name});ET.SubElement(g,T('circle'),{'cx':str(x),'cy':str(y),'r':str(r),'fill':col,'stroke':'#fff','stroke-width':'.65'});title=ET.SubElement(g,T('title'));title.text=name+' | '+n['role']+' | '+regions[n['region_id']]['name']
        draw.ellipse((px(x-r),px(y-r),px(x+r),px(y+r)),fill=col,outline='#ffffff',width=1)
        if name in labels:
            lx,ly,l,z=labels[name];text(lx,ly,l,z,'#304f6b')
    for c in clusters:
        if c['reused']:
            p=nodes[c['parent']];text(p['x']+13,p['y']+27,'×'+str(c['count']),11,'#7b8ea1')
    text(55,1765,'虚线框为模型建议组，非已确认安全域；橙框表示部分关联缺少连接证据，待核实。同父同类单邻居可重叠。',15,'#647990')
    svg=ET.tostring(root,encoding='unicode');(out/'整体网络拓扑.svg').write_text(svg,encoding='utf-8')
    fd,tmp=tempfile.mkstemp(prefix='topology_',suffix='.png',dir=out);os.close(fd)
    try:
        image.save(tmp,format='PNG',optimize=True)
        with Image.open(tmp) as check:check.load()
        os.replace(tmp,out/'整体网络拓扑_4K.png')
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    viewer={'nodes':[{'name':n['name'],'x':n['x'],'y':n['y'],'role':n['role'],'region_name':regions[n['region_id']]['name'],'known':n['known'],'ip':n.get('ip','')} for n in nodes.values()],
            'edges':[{'a':a,'b':b} for a,b in pairs], 'clusters':clusters}
    serialized=json.dumps(viewer,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    template=Path(__file__).with_name('viewer_template.html').read_text(encoding='utf-8')
    page=template.replace('__SVG__',svg).replace('__PAYLOAD__',serialized)
    (out/'整体网络拓扑_交互.html').write_text(page,encoding='utf-8')
    return shown

def excel(nodes,edges,regions,boxes,clusters,out):
    wb=Workbook();wb.remove(wb.active)
    def sheet(name,headers,rows):
        s=wb.create_sheet(name);s.append(headers)
        for row_index,row in enumerate(rows,2):
            for column_index,v in enumerate(row,1):
                v=str(v) if isinstance(v,(list,dict)) else v
                c=s.cell(row=row_index,column=column_index,value=v)
                if isinstance(v,str) and v.startswith(('=','+','-','@')):c.data_type='s'
        s.freeze_panes='B2';s.auto_filter.ref=s.dimensions
        for cell in s[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='345470');cell.alignment=Alignment(wrap_text=True)
        for i,h in enumerate(headers,1):s.column_dimensions[get_column_letter(i)].width=32 if any(q in h for q in ('名称','依据','成员')) else 18
    sheet('网元坐标',['网元名称','X','Y','角色','角色依据','区域ID','区域名称','原网元表','邻居数','源表行','原始角色','原始区域','有效IP','源IP字段原值'],[[n['name'],n['x'],n['y'],n['role'],n['role_basis'],n['region_id'],regions[n['region_id']]['name'],n['known'],n['degree'],','.join(map(str,n['inventory_rows'])),n['raw_role'],n['raw_region'],n['ip'],n.get('ip_raw','')] for n in nodes.values()])
    sheet('原始链路',['源网元','宿网元','源端口','宿端口','类型','带宽原值','原工作表','原始行'],[[e['a'],e['b'],e['a_port'],e['b_port'],e['type'],e['bandwidth'],e['sheet'],e['row']] for e in edges])
    sheet('布局区域',['区域ID','区域名称','名称来源','依据','左上X','左上Y','右下X','右下Y'],[[rid,r['name'],r['source'],r['basis'],*boxes[rid]] for rid,r in regions.items()])
    sheet('同父叶子组',['父网元','数量','可视位置','复用数量','区域','成员'],[[c['parent'],c['count'],c['visual_slots'],c['reused'],c['region'],'；'.join(c['members'])] for c in clusters])
    wb.save(out/'网元坐标与链路.xlsx')
