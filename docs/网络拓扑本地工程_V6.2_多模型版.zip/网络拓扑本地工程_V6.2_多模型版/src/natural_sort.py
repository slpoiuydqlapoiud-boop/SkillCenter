import re
def natural_key(s):return [int(x) if x.isdigit() else x.upper() for x in re.split(r'(\d+)',s)]
