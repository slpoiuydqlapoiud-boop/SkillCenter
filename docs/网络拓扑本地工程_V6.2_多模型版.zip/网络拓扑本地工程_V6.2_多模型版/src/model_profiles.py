"""Each named profile overrides the legacy shared model configuration."""
import json,re
from pathlib import Path

def load_profiles(root):
    path=Path(root)/'模型服务.json'
    if not path.exists():return {'default_profile':'legacy','profiles':{'legacy':{'label':'原有模型配置'}}}
    doc=json.loads(path.read_text(encoding='utf-8-sig'))
    profiles=doc.get('profiles') if isinstance(doc,dict) else None
    if not isinstance(profiles,dict) or not profiles:raise ValueError('模型服务.json 的 profiles 必须是非空对象')
    for name,profile in profiles.items():
        if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',name):raise ValueError('模型配置名仅支持英文字母、数字、下划线和短横线，最长 40 位')
        if not isinstance(profile,dict):raise ValueError('模型配置 '+name+' 必须是 JSON 对象')
        if any(k.lower() in ('api_key','apikey','token','authorization') for k in profile):raise ValueError('请勿把 API Key 写入模型服务.json，使用 api_key_env 或启动时输入')
    if doc.get('default_profile') not in profiles:raise ValueError('default_profile 未对应 profiles 中的配置')
    return doc

def resolve(root,name=None):
    doc=load_profiles(root);name=name or doc['default_profile']
    if name not in doc['profiles']:raise ValueError('模型配置不存在：'+str(name)+'；请使用 --list-profiles 查看')
    base=json.loads((Path(root)/'模型配置.json').read_text(encoding='utf-8-sig'))
    if not isinstance(base,dict):raise ValueError('模型配置.json 必须是 JSON 对象')
    selected=doc['profiles'][name];cfg=dict(base);cfg.update({k:v for k,v in selected.items() if k!='label'})
    cfg['_profile_id']=name
    for field in ('url','model','api_key_env'):
        if not isinstance(cfg.get(field),str) or not cfg[field].strip():raise ValueError(name+' 的 '+field+' 必须为非空字符串')
    if 'example.com' in cfg['url'] or '请填写' in cfg['model']:raise ValueError('请先填写 模型服务.json 中 '+name+' 的真实 url 和 model')
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',cfg['api_key_env']):raise ValueError('api_key_env 必须是合法环境变量名')
    return name,cfg
