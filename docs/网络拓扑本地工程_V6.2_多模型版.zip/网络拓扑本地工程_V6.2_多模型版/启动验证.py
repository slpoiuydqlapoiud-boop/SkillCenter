#!/usr/bin/env python3
import argparse,getpass,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
def main():
    p=argparse.ArgumentParser(description='网络拓扑：可选择多个模型服务配置')
    p.add_argument('--prepare-only',action='store_true',help='只生成无局部组的事实页，不调用模型')
    p.add_argument('--historical-model-groups',help='回放用户提供的历史模型组，仅供验证，不调用模型')
    p.add_argument('--resume',nargs='?',const='latest',help='恢复上一次运行；也可指定 output 下的运行目录')
    p.add_argument('--profile',help='模型配置名，定义在 模型服务.json；不指定则使用默认配置')
    p.add_argument('--list-profiles',action='store_true',help='显示已配置的模型服务，不调用接口')
    args=p.parse_args()
    if args.prepare_only and args.historical_model_groups:p.error('两个模式不能同时使用')
    from model_profiles import load_profiles,resolve
    if args.list_profiles:
        settings=load_profiles(ROOT)
        for name,profile in settings['profiles'].items():print(name+'：'+str(profile.get('label',name))+('（默认）' if name==settings['default_profile'] else ''))
        return 0
    try:
        import openpyxl,numpy
        from PIL import Image
    except ImportError as e:raise RuntimeError('缺少依赖，请先执行 python -m pip install -r requirements.txt：'+str(e)) from None
    profile,cfg=resolve(ROOT,args.profile);token=None
    print('选择的模型配置：'+profile+'；模型：'+cfg['model'],flush=True)
    if not args.prepare_only and not args.historical_model_groups:
        env_name=cfg.get('api_key_env','TOPOLOGY_LLM_API_KEY')
        token=os.environ.get(env_name) or getpass.getpass(f'请输入配置 {profile} 的 API Key（或设置 {env_name}，输入不回显）：')
        if not token.strip():raise ValueError('模型密钥为空')
    from pipeline import run
    resume_dir=None
    if args.resume:
        if args.resume=='latest':
            marker=ROOT/'output'/f'最新运行目录_{profile}.txt'
            if not marker.exists() and profile=='legacy':marker=ROOT/'output'/'最新运行目录.txt'
            if not marker.exists():raise ValueError('没有此模型配置的运行记录；请先启动运行或给 --resume 指定目录')
            resume_dir=marker.read_text(encoding='utf-8').strip()
        else:resume_dir=args.resume
    out=run(ROOT,cfg,token,prepare_only=args.prepare_only,replay_groups=args.historical_model_groups,resume_dir=resume_dir)
    report=out/'处理校验报告.json'
    if not args.prepare_only and report.exists() and json.loads(report.read_text(encoding='utf-8')).get('model_run_incomplete'):
        print(f'执行未完成：已输出预览，可用 python 启动验证.py --profile {profile} --resume 继续。',file=sys.stderr)
        return 2
    return 0
if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        import traceback
        target=ROOT/'output';target.mkdir(exist_ok=True)
        log=target/('异常_'+str(os.getpid())+'.txt')
        log.write_text(traceback.format_exc(),encoding='utf-8')
        print('执行失败：'+str(e)+'；请查看 '+str(log),file=sys.stderr);sys.exit(1)
