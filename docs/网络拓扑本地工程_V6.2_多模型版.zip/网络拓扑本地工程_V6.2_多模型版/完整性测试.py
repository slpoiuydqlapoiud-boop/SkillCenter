#!/usr/bin/env python3
"""Tests of paging, model-only groups, validation and cross-page decisions."""
import copy,json,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'src'))
import v6_analysis as v
nodes={x:{'name':x,'known':True,'raw_role':'','raw_region':'','device_type':'','source_attributes':{'1:备注':'证据'}} for x in ['A','B','C','I']}
edges=[{'a':'A','b':'B','a_port':'p','b_port':'q','type':'physical','bandwidth':'1000','sheet':'链接','row':2,'source_attributes':{'1:带宽':'1000'}},{'a':'B','b':'C','a_port':'r','b_port':'s','type':'physical','bandwidth':'10000','sheet':'链接','row':3,'source_attributes':{'1:带宽':'10000'}}]
pages=v.pages(nodes,edges,max_edges=1,max_chars=20000)
assert {n['name'] for p in pages for n in p['nodes']}==set(nodes)
assert sorted(e['id'] for p in pages for e in p['edges'])==['L0000001','L0000002']
assert all('groups' not in p and 'structural_groups' not in p for p in pages)
assert pages[0]['edges'][0]['source_attributes']['1:带宽']=='1000'
print('通过：事实分页覆盖全部节点、链路和原始字段；输入没有预设局部组。')
adj={'A':{'B'},'B':{'A','C'},'C':{'B'},'I':set()};region={n:'R' for n in nodes}
raw=[{'id':'P1','name':'模型组','parents':[],'members':['A','B'],'evidence_edge_ids':['L0000001']},{'id':'P2','name':'证据不足','parents':[],'members':['A','I']},{'id':'P3','name':'虚构设备','parents':[],'members':['A','X']}]
a,b=v.validate_groups(raw,nodes,adj,region)
assert len(a)==2 and len(b)==1 and not a[0]['verification']['needs_expert_review'] and a[1]['verification']['needs_expert_review']
print('通过：虚构网元拒绝；真实但连接证据不足的模型组保留并标记待核实。')
proposals=[{'id':f'P{i}','name':f'模型组{i}','parents':[],'members':['A','B'],'evidence_edge_ids':[]} for i in range(5)]
seen=[];orig=v.call
def mock_call(cfg,token,inp,out,prompt=None):
    seen.append([x['id'] for x in inp['proposal_groups']]);return {'reviewed_proposal_ids':[x['id'] for x in inp['proposal_groups']],'operations':[],'region_names':[],'backbone_nodes':[]},{}
v.call=mock_call
with tempfile.TemporaryDirectory() as t:
    result,stats,_,_=v.run_merge({'merge_groups_per_batch':2,'max_merge_pair_batches':20},'test',proposals,[],[],[],Path(t),adj,{n:dict(name=n) for n in nodes},[])
assert len(result)==5 and len(seen)==15 and stats['pairwise_model_batches']==15
for i in range(5):
 for j in range(i+1,5):assert any({f'P{i}',f'P{j}'}<=set(s) for s in seen)
print('通过：跨页组两两交由模型比较；没有模型合并决策时程序不创建合并组。')
# Missing self-reports are recorded, never counted as reviewed.
tries=[]
def bad_call(cfg,token,inp,out,prompt=None):
    tries.append(1);return {'reviewed_nodes':[],'reviewed_edges':[],'groups':[]},{}
v.call=bad_call
with tempfile.TemporaryDirectory() as t:
    returned=v.run_maps({'max_parallel_model_calls':1,'max_review_retries':1},'test',[pages[0]],Path(t))
    assert len(tries)==1 and returned[1][0]['missing_nodes'] and returned[1][0]['missing_edges'] and returned[-1] is None
v.call=orig
print('通过：模型漏报覆盖时保留原始结果并明确记录遗漏，不虚报已检查。')
# Overlapping model merge claims must be adjudicated by the model, not unioned by code.
proof=[]
def merge_mock(cfg,token,inp,out,prompt=None):
    ids=[x['id'] for x in inp['proposal_groups']];proof.append(('prior_model_merge_suggestions' in inp,ids))
    if 'prior_model_merge_suggestions' in inp:return {'reviewed_proposal_ids':ids,'operations':[{'op':'merge','ids':['P0','P1'],'name':'模型确认合并'}]},{}
    ops=[]
    if {'P0','P1'}<=set(ids):ops.append({'op':'merge','ids':['P0','P1'],'name':'模型候选合并'})
    if {'P1','P2'}<=set(ids):ops.append({'op':'merge','ids':['P1','P2'],'name':'模型候选合并'})
    return {'reviewed_proposal_ids':ids,'operations':ops},{}
v.call=merge_mock
with tempfile.TemporaryDirectory() as t:
    result,stats,_,_=v.run_merge({'merge_groups_per_batch':4,'max_merge_pair_batches':10},'test',proposals,[],[],[],Path(t),adj,{n:dict(name=n) for n in nodes},[])
assert any(flag for flag,ids in proof) and len(result)==4
assert any(set(g.get('merged_from',[]))=={'P0','P1'} for g in result) and any(g['id']=='P2' for g in result)
v.call=orig
print('通过：模型合并建议冲突时由模型再次仲裁，程序不会自动传递合并。')
# Duplicate-name inventory rows remain separate pieces of source evidence.
from openpyxl import Workbook
from excel_io import read
with tempfile.TemporaryDirectory() as t:
    path=Path(t)/'test.xlsx';w=Workbook();s=w.active;s.title='网元';s.append(['网元名称','备注']);s.append(['A','one']);s.append(['A','two']);l=w.create_sheet('链路');l.append(['源网元名称','宿网元名称']);l.append(['A','B']);w.save(path)
    ns,es,summary=read(path,{'网元表':{'sheet':'网元','header_row':1},'链路表':{'sheet':'链路','header_row':1}})
    assert len(ns['A']['source_inventory_records'])==2 and len(summary['duplicate_names'])==1
    pgs=v.pages(ns,es,max_edges=2,max_chars=20000);a=next(n for p in pgs for n in p['nodes'] if n['name']=='A')
    assert len(a['source_inventory_records'])==2
print('通过：同名网元暂按名称合并，但两条源表记录都进入模型事实页。')
# A model-proposed parent/member group must actually affect constrained placement.
import pipeline
with tempfile.TemporaryDirectory() as t:
    root=Path(t);w=Workbook();s=w.active;s.title='网元';s.append(['网元名称','网元角色']);s.append(['ROOT','core']);s.append(['ROOT2','core']);s.append(['P1','aggregation']);s.append(['P2','aggregation'])
    for i in range(4):s.append([f'C{i}','access'])
    l=w.create_sheet('链路');l.append(['源网元名称','宿网元名称']);l.append(['ROOT','ROOT2']);l.append(['ROOT','P1']);l.append(['ROOT2','P2'])
    for i in range(4):l.append(['P1',f'C{i}']);l.append(['P2',f'C{i}'])
    w.save(root/'input.xlsx');(root/'字段映射.json').write_text(json.dumps({'网元表':{'sheet':'网元','header_row':1},'链路表':{'sheet':'链路','header_row':1}},ensure_ascii=False),encoding='utf-8')
    def run_fixture(enable):
        def fake(cfg,token,inp,out,prompt=None):
            if 'page_id' in inp:
                groups=[{'name':'模型提出的双父组','parents':['P1','P2'],'members':[f'C{i}' for i in range(4)],'evidence_edge_ids':[]}] if enable else []
                return {'reviewed_nodes':[n['name'] for n in inp['nodes']],'reviewed_edges':[e['id'] for e in inp['edges']],'groups':groups,'region_suggestions':[{'name':'模型自主区域','members':[n['name'] for n in inp['nodes']],'position_x':.4}] if enable else []},{}
            return {'reviewed_proposal_ids':[p['id'] for p in inp['proposal_groups']],'operations':[]},{}
        v.call=fake
        path=pipeline.run(root,{'max_edges_per_batch':180,'max_batch_chars':115000,'layout_refinement_iterations':0,'mock_simulation':True},'test')
        return json.loads((path/'渲染数据与布局结果.json').read_text(encoding='utf-8')),json.loads((path/'处理校验报告.json').read_text(encoding='utf-8'))
    without,wo=run_fixture(False);with_group,wg=run_fixture(True);v.call=orig
    assert wo['validated_model_groups']==0 and wo['displayed_model_group_frames']==0
    assert all(n['region_id']=='MR001' for n in with_group['nodes']) and any(r['name']=='模型自主区域' and r['source']=='model' for r in with_group['regions'])
    assert wg['validated_model_groups']==1 and wg['structural_layout_candidates']==1 and wg['structural_layout_groups_placed']==1 and wg['displayed_model_group_frames']==1 and wg['placement']['structural_groups_placed']==1
    n0={n['name']:(n['x'],n['y']) for n in without['nodes']};n1={n['name']:(n['x'],n['y']) for n in with_group['nodes']}
    assert any(n0[n]!=n1[n] for n in ['P1','P2','C0','C1','C2','C3'])
print('通过：空模型组不会生成局部组；模型自主大区可生效；模型父子组能改变坐标并生成边界。')
# Feasible model layout must not be overridden just because graph-depth scores higher.
from structure_placement import place_structures
xx={};rr={};coords={};hs=set()
for n in ['P','C1','C2','C3','C4']:
 xx[n]={'role':'aggregation' if n=='P' else 'access','backbone_distance':1 if n=='P' else 2,'is_backbone':False};rr[n]='R';coords[n]=(200,500);hs.add(n)
g=[{'id':'P1','name':'模型布局','region':'R','kind':'model_proposal','parents':['P'],'members':['C1','C2','C3','C4'],'member_count':4,'basis':'模型建议','relative_depth':'deep','priority':'normal','layout_kind':'grid','space_weight':1.0}]
_,_,_,meta=place_structures(xx,hs,rr,{'R':[50,365,1050,1700]},coords,g)
assert meta['selected_strategy']=='model_relative' and meta['structural_groups_placed']==1
print('通过：模型布局可行时优先保留，不因图距离启发分数更高而覆盖。')
# The horizontal order suggested by the model is consumed by the layout.
xx={};rr={};coords={};hs=set();gg=[]
for j in range(2):
    parent=f'P{j}';children=[f'K{j}{k}' for k in range(4)]
    for n in [parent]+children:
        xx[n]={'role':'aggregation' if n==parent else 'access','backbone_distance':1 if n==parent else 2,'is_backbone':False};rr[n]='R';coords[n]=(200,500);hs.add(n)
    gg.append({'id':f'M{j}','name':'模型组','region':'R','kind':'model_proposal','parents':[parent],'members':children,'member_count':4,'basis':'模型建议','relative_depth':'near','priority':'normal','layout_kind':'grid','space_weight':1.0,'position_x':.1 if j==0 else .9})
a,_,_,_=place_structures(xx,hs,rr,{'R':[50,365,1550,1700]},dict(coords),gg)
gg[0]['position_x'],gg[1]['position_x']=gg[1]['position_x'],gg[0]['position_x']
b,_,_,_=place_structures(xx,hs,rr,{'R':[50,365,1550,1700]},dict(coords),gg)
assert a['P0'][0]<a['P1'][0] and b['P0'][0]>b['P1'][0]
print('通过：模型结构组相对顺序会实际改变布局。')
